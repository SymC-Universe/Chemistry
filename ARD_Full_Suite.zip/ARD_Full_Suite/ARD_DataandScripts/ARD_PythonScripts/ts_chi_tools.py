#!/usr/bin/env python3
import argparse, csv, math
from dataclasses import dataclass
from pathlib import Path

HC_EV_CM = 1.23984193e-4
WINDOW_MIN = 0.8
WINDOW_MAX = 1.2

def chi_route_c(gamma_cat_ev, nu_cm1, gamma_int_ev=0.0):
    return (gamma_cat_ev + gamma_int_ev) / (2.0 * HC_EV_CM * nu_cm1)

def regime_label(chi):
    if chi < WINDOW_MIN:
        return "underdamped"
    if chi <= WINDOW_MAX:
        return "near-critical"
    return "overdamped"

@dataclass
class Row:
    label: str
    nu_barrier_cm1: float
    gamma_cat_ev: float
    gamma_int_ev: float

def run_from_csv(in_csv, out_csv="chi_ts_results.csv"):
    rows = []
    with open(in_csv, newline="") as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append(Row(
                r["label"],
                float(r["nu_barrier_cm1"]),
                float(r["gamma_cat_ev"]),
                float(r.get("gamma_int_ev", 0) or 0),
            ))

    out = []
    chis = []

    for r in rows:
        chi = chi_route_c(r.gamma_cat_ev, r.nu_barrier_cm1, r.gamma_int_ev)
        reg = regime_label(chi)
        out.append([r.label, r.nu_barrier_cm1, r.gamma_cat_ev, r.gamma_int_ev, chi, reg])
        chis.append(chi)

    with open(out_csv, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["label","nu_barrier_cm1","gamma_cat_ev","gamma_int_ev","chi","regime"])
        writer.writerows(out)

    print("TS χ range:", min(chis), "→", max(chis))
    print("Near-critical window:", WINDOW_MIN, "to", WINDOW_MAX)
    print("Output written to:", out_csv)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("csv")
    parser.add_argument("--out", default="chi_ts_results.csv")
    args, _ = parser.parse_known_args()
    run_from_csv(args.csv, args.out)
