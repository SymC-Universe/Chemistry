"""
Test8_pValueCal.py
Exact analytical p-value for Test 8 cross-domain clustering.

Corrections vs original:
  - N: 4 -> 3 (three candidate anchors: catalysis, ET structural, PCET mechanistic)
  - Window: [0.8, 1.2] -> [0.8, 1.3] (manuscript operational band)
  - p_single: 3.52% -> 4.217%
  - p_N3: 4.37e-5 -> 7.50e-5

Note: Test 8 is prospective. Only the catalysis anchor (K-promoted Fe(111),
chi_DFT = 1.2825, Route C) provides a direct numerical chi estimate.
ET and PCET anchors are structural/mechanistic. Test 8 becomes a formal
statistical validation when all three domains have direct chi estimates.
"""

import numpy as np

print("--- EXACT ANALYTICAL P-VALUE CALCULATION (Test 8) ---\n")

# Log-uniform prior: 5 decades from 1e-4 to 1e1
log_range_total = 1.0 - (-4.0)   # = 5.0

# Operational near-critical window [0.8, 1.3]
window_width = np.log10(1.3) - np.log10(0.8)

p_single = window_width / log_range_total
print(f"Near-critical window:                [0.8, 1.3]")
print(f"Log-uniform prior range:             [1e-4, 1e1]  ({log_range_total} decades)")
print(f"Probability of 1 system in window:   {p_single*100:.3f}%")

# Three candidate anchors
N = 3
exact_p_value = p_single ** N

print(f"\nCandidate anchor systems (N={N}):")
print(f"  1. Catalysis  -- K-promoted Fe(111), chi_DFT = 1.2825 (Route C, direct)")
print(f"  2. ET         -- PGH structural argument (rate turnover maximum near chi=1)")
print(f"  3. PCET       -- near-zero activation volume in concerted regime (mechanistic)")

print(f"\nExact analytical p-value:  {exact_p_value:.2e}")
print(f"log10(p):                  {np.log10(exact_p_value):.3f}")

if exact_p_value < 0.05:
    print(f"\nResult: p < 0.05 -- statistically significant under the stated prior.")
    print("Test 8 is prospective: formal validation requires direct chi estimates")
    print("in all three domains. Current result demonstrates framework sensitivity.")

# Robustness sweep
print("\n--- PRIOR ROBUSTNESS SWEEP ---")
print(f"{'Prior range':<22}  {'Window':<12}  {'p_single':>9}  {'p_N3':>12}")
for xmin, xmax in [(-5, 1), (-4, 1), (-4, 2), (-4, 3)]:
    for lo, hi in [(0.8, 1.3), (0.75, 1.35), (0.7, 1.4), (0.85, 1.25)]:
        r = xmax - xmin
        w = np.log10(hi) - np.log10(lo)
        p1 = w / r
        pN = p1 ** N
        rng = f"[1e{xmin}, 1e{xmax}]"
        win = f"[{lo},{hi}]"
        print(f"  {rng:<20}  {win:<12}  {p1*100:>8.3f}%  {pN:>12.2e}")
