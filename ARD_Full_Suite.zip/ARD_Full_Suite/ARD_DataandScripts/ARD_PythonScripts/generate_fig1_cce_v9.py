"""
generate_fig1_cce_v9.py

Corrected Figure 1 generator for CCE v9.

The main curve is a reduced symmetric turnover schematic:
    eta(chi) = 2 chi / (1 + chi^2)
It is not a full PGH/Mel'nikov-Meshkov numerical rate and it is not an
independent empirical fit.

Figure logic:
1. Route C Fe/N2 points are plotted on the absolute chi axis using
   chi = Gamma / (2 h c nu).
2. TEMPO Route B is shown only as a relative inset because tau_L alone does
   not provide an absolute chi anchor.
3. Main-panel y-values are model projections onto eta(chi), not measured rates.

Outputs:
    Fig1_Dynamical_Efficiency_Tracker.png
    Fig1_Dynamical_Efficiency_Tracker.svg
    Fig1_Dynamical_Efficiency_Tracker_data.csv
"""

from __future__ import annotations

import csv
import math
import os
from dataclasses import dataclass

import matplotlib.pyplot as plt
import numpy as np

HC_EV_CM = 1.23984193e-4  # h*c in eV*cm


def eta_schematic(chi: float | np.ndarray) -> float | np.ndarray:
    """Reduced symmetric turnover schematic: eta = 2 chi / (1 + chi^2)."""
    chi = np.asarray(chi, dtype=float)
    return (2.0 * chi) / (1.0 + chi**2)


def route_c_chi(gamma_ev: float, nu_cm1: float, gamma_int_ev: float = 0.0) -> float:
    """Route C damping ratio from energy broadening and vibrational wavenumber."""
    if gamma_ev < 0.0 or gamma_int_ev < 0.0:
        raise ValueError("Energy broadenings must be nonnegative.")
    if nu_cm1 <= 0.0:
        raise ValueError("Wavenumber must be positive.")
    return (gamma_ev + gamma_int_ev) / (2.0 * HC_EV_CM * nu_cm1)


def eta_threshold_roots(threshold: float = 0.95) -> tuple[float, float]:
    """Analytic roots of 2 chi/(1 + chi^2) = threshold."""
    if not (0.0 < threshold < 1.0):
        raise ValueError("threshold must be between 0 and 1.")
    root = math.sqrt(1.0 - threshold**2)
    return (1.0 - root) / threshold, (1.0 + root) / threshold


@dataclass(frozen=True)
class RouteCPoint:
    label: str
    gamma_ev: float
    nu_cm1: float
    marker: str
    offset: tuple[int, int]

    @property
    def chi(self) -> float:
        return route_c_chi(self.gamma_ev, self.nu_cm1)

    @property
    def eta(self) -> float:
        return float(eta_schematic(self.chi))


def write_data_csv(path: str, route_c_points: list[RouteCPoint], tempo_rows: list[tuple[str, float, float]]) -> None:
    """Write numerical values used in the figure."""
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["series", "label", "x_value", "y_value", "notes"])
        for p in route_c_points:
            writer.writerow([
                "Route C absolute", p.label, f"{p.chi:.10g}", f"{p.eta:.10g}",
                "x=Gamma/(2hcnu); y=projection onto schematic eta(chi)",
            ])
        for solvent, tau_l, chi_rel in tempo_rows:
            writer.writerow([
                "Route B TEMPO relative", solvent, f"{chi_rel:.10g}", "not on main eta curve",
                f"tau_L={tau_l:g} ps; chi_rel=tau_L/tau_MeCN; no absolute chi anchor",
            ])


def generate_efficiency_tracker(output_dir: str = ".") -> tuple[str, str, str]:
    chi_vals = np.logspace(-5, 2, 1600)
    eta_vals = eta_schematic(chi_vals)
    lo95, hi95 = eta_threshold_roots(0.95)

    fig, ax = plt.subplots(figsize=(10.2, 6.4))

    ax.plot(chi_vals, eta_vals, linewidth=2.2,
            label=r"Reduced schematic: $\eta=2\chi/(1+\chi^2)$")

    # Boundary markers rather than shaded bands, to avoid visually implying fitted data.
    ax.axvline(lo95, linestyle=":", linewidth=1.0, alpha=0.65,
               label=rf"Schematic $\eta\geq0.95$ roots: [{lo95:.2f},{hi95:.2f}]")
    ax.axvline(hi95, linestyle=":", linewidth=1.0, alpha=0.65)
    ax.axvline(0.8, linestyle="--", linewidth=1.0, alpha=0.80,
               label=r"Operational band: $\chi\in[0.8,1.3]$")
    ax.axvline(1.3, linestyle="--", linewidth=1.0, alpha=0.80)
    ax.axvline(1.0, linestyle="-", linewidth=1.0, alpha=0.85)
    ax.axhline(0.95, linestyle=":", linewidth=1.1, alpha=0.75)
    ax.text(1.04, 0.07, r"$\chi=1$", fontsize=10)
    ax.text(1.25e-5, 0.958, r"$\eta=0.95$", fontsize=10)

    route_c_points = [
        RouteCPoint(r"N$_2$ gas phase", 1.0e-5, 2359.0, "x", (38, 4)),
        RouteCPoint(r"Fe(111) bare", 0.05, 2100.0, "s", (8, 14)),
        RouteCPoint(r"Fe(110)", 0.30, 2000.0, "D", (-36, 16)),
        RouteCPoint(r"K-Fe(111)", 0.45, 1415.0, "^", (34, -13)),
    ]

    for idx, p in enumerate(route_c_points):
        ax.scatter(p.chi, p.eta, marker=p.marker, s=88, zorder=5,
                   label=r"Route C / gas proxy" if idx == 0 else None)
        dx, dy = p.offset
        ax.annotate(
            f"{p.label}\n" + rf"$\chi={p.chi:.2g}$",
            (p.chi, p.eta), textcoords="offset points", xytext=(dx, dy),
            ha="left" if idx == 0 else "center", fontsize=9,
        )

    # TEMPO inset: tau_L-relative only; not absolute chi.
    tempo_tau = [
        ("MeCN", 0.20),
        ("H2O", 0.20),
        ("D2O", 0.30),
        ("THF", 0.80),
        ("PC", 1.20),
    ]
    tau_ref = tempo_tau[0][1]
    tempo_rows = [(name, tau, tau / tau_ref) for name, tau in tempo_tau]
    solvents = [row[0] for row in tempo_rows]
    rel_vals = np.array([row[2] for row in tempo_rows], dtype=float)

    inset = ax.inset_axes([0.12, 0.53, 0.33, 0.34])
    x = np.arange(len(solvents))
    inset.plot(x, rel_vals, marker="o", linewidth=1.6)
    inset.axhline(0.8, linestyle="--", linewidth=0.8, alpha=0.7)
    inset.axhline(1.3, linestyle="--", linewidth=0.8, alpha=0.7)
    inset.set_xticks(x)
    inset.set_xticklabels(solvents, rotation=35, ha="right", fontsize=8)
    inset.set_ylabel(r"$\chi_{rel}$", fontsize=8)
    inset.set_title(r"TEMPO Route B: $\tau_L$-relative only", fontsize=8)
    inset.tick_params(axis="y", labelsize=8)
    inset.grid(True, linestyle="--", alpha=0.18)
    inset.text(0.03, 0.96, r"not absolute $\chi$; $\Omega_s$ not applied",
               transform=inset.transAxes, va="top", fontsize=7)

    ax.set_xscale("log")
    ax.set_xlim(1e-5, 1e2)
    ax.set_ylim(0.0, 1.08)
    ax.set_xlabel(r"Approach-dynamics damping ratio $\chi=\Gamma_{\rm eff}/(2\Omega_0)$", fontsize=12)
    ax.set_ylabel(r"Model-projected normalized rate $\eta(\chi)$", fontsize=12)
    ax.set_title("Dynamical Efficiency Map Across Chemical Domains", fontsize=14, fontweight="bold")
    ax.grid(True, which="both", linestyle="--", alpha=0.16)
    ax.legend(loc="lower right", fontsize=8.6, framealpha=0.95)

    fig.text(
        0.5, 0.005,
        "Note: y-values on the main curve are model projections from the schematic eta(chi), not independent measured rates. "
        "The TEMPO inset is relative Route B placement only; absolute chi requires calibration.",
        ha="center", fontsize=8,
    )

    plt.tight_layout(rect=[0, 0.03, 1, 1])

    os.makedirs(output_dir, exist_ok=True)
    png_path = os.path.join(output_dir, "Fig1_Dynamical_Efficiency_Tracker.png")
    svg_path = os.path.join(output_dir, "Fig1_Dynamical_Efficiency_Tracker.svg")
    csv_path = os.path.join(output_dir, "Fig1_Dynamical_Efficiency_Tracker_data.csv")

    fig.savefig(png_path, dpi=300, bbox_inches="tight", transparent=True)
    fig.savefig(svg_path, format="svg", bbox_inches="tight", transparent=True)
    write_data_csv(csv_path, route_c_points, tempo_rows)
    plt.close(fig)

    return png_path, svg_path, csv_path


if __name__ == "__main__":
    paths = generate_efficiency_tracker(output_dir=os.getcwd())
    for path in paths:
        print(path)
