"""
stability_methods.py

Computational methods for the Symmetrical Convergence (SymC) Critical Damping Framework.

This module implements the three "How to Compute χ in Practice" routes used in the
physical chemistry upgrade, plus the exact analytical p value for Test 8 in Transition-State Damping as a Mechanistic Descriptor of
Rate Turnover in Chemical Reactivity.

Routes:
  A) Spectroscopic proxy (χ_spec) from Lorentzian FWHM and peak frequency, both in cm^-1
  B) Solvent relaxation (χ_ET) for a Marcus reorganization coordinate, with strict SI conversion
  C) Electronic friction from DFT (χ_total) from energy linewidths (eV) and frequency (cm^-1)

Test 8:
  Exact analytical probability (log-uniform prior) that N optimal systems fall inside the
  critical window purely by chance.

Author: Nate Christensen (SymC Universe Project)
Date: February 2026

"""

from __future__ import annotations

from dataclasses import dataclass
from math import sqrt, log10, isfinite
from typing import Dict


# =========================
# Constants (exact where defined)
# =========================

EV_TO_JOULES: float = 1.602176634e-19          # J per eV (exact, SI definition)
AMU_TO_KG: float = 1.66053906660e-27           # kg per amu (CODATA 2018)
ANGSTROM_TO_M: float = 1.0e-10                 # m per Å
PS_TO_S: float = 1.0e-12                       # s per ps
HC_EV_CM: float = 1.23984193e-4                # (h*c) in eV·cm (standard spectroscopy constant)


# =========================
# Small utilities
# =========================

def _require_finite(x: float, name: str) -> None:
    if not isfinite(x):
        raise ValueError(f"{name} must be finite. Got {x!r}")

def _require_positive(x: float, name: str) -> None:
    _require_finite(x, name)
    if x <= 0.0:
        raise ValueError(f"{name} must be > 0. Got {x!r}")

def _require_nonnegative(x: float, name: str) -> None:
    _require_finite(x, name)
    if x < 0.0:
        raise ValueError(f"{name} must be >= 0. Got {x!r}")


# =====================================================================
# ROUTE A: Spectroscopic proxy (χ_spec)
# =====================================================================

def chi_route_a(delta_nu_L_cm1: float, nu_cm1: float) -> float:
    """
    Spectroscopic proxy for χ when both linewidth and frequency are reported
    as wavenumbers (cm^-1).

    IMPORTANT:
      delta_nu_L_cm1 MUST be the Lorentzian-only FWHM component (from a Voigt fit),
      not the raw instrument-reported FWHM.

    Physics:
      For a damped oscillator with homogeneous lifetime broadening, the Lorentzian
      full width at half maximum (FWHM) provides a direct damping scale.

    Math:
      χ = Δν̃_L / (2 ν̃)

      All constants (h and c) cancel exactly because both inputs are in cm^-1.

    Args:
      delta_nu_L_cm1: Lorentzian FWHM linewidth in cm^-1 (Voigt Lorentzian component)
      nu_cm1: Peak frequency in cm^-1

    Returns:
      Dimensionless damping ratio χ
    """
    _require_positive(delta_nu_L_cm1, "delta_nu_L_cm1")
    _require_positive(nu_cm1, "nu_cm1")
    return delta_nu_L_cm1 / (2.0 * nu_cm1)


# =====================================================================
# ROUTE B: Solvent relaxation (χ_ET)
# =====================================================================

def chi_route_b(tau_l_ps: float, lambda_ev: float, delta_q_angstrom: float, m_eff_amu: float) -> float:
    """
    Solvent relaxation route for χ for a Marcus reorganization coordinate.

    Physics:
      Model the solvent reorganization coordinate as a damped harmonic mode.
      Use macroscopic dielectric friction via the longitudinal relaxation time.

    Math (SI):
      k = 2λ / (ΔQ)^2
      Ω = sqrt(k / m_eff)
      Γ = 1 / τ_L
      χ = Γ / (2Ω)

    Args:
      tau_l_ps: Longitudinal dielectric relaxation time τ_L in picoseconds
      lambda_ev: Reorganization energy λ in eV
      delta_q_angstrom: Coordinate displacement ΔQ in Å
      m_eff_amu: Effective mass m_eff of the collective mode in amu

    Returns:
      Dimensionless damping ratio χ
    """
    _require_positive(tau_l_ps, "tau_l_ps")
    _require_positive(lambda_ev, "lambda_ev")
    _require_positive(delta_q_angstrom, "delta_q_angstrom")
    _require_positive(m_eff_amu, "m_eff_amu")

    tau_l_s = tau_l_ps * PS_TO_S
    lam_j = lambda_ev * EV_TO_JOULES
    delta_q_m = delta_q_angstrom * ANGSTROM_TO_M
    m_eff_kg = m_eff_amu * AMU_TO_KG

    k = (2.0 * lam_j) / (delta_q_m * delta_q_m)
    omega = sqrt(k / m_eff_kg)
    gamma = 1.0 / tau_l_s

    return gamma / (2.0 * omega)


# =====================================================================
# ROUTE C: Electronic friction from DFT (χ_total)
# =====================================================================

def chi_route_c(gamma_cat_ev: float, nu_cm1: float, gamma_int_ev: float = 0.0) -> float:
    """
    Electronic friction route for χ using energy linewidths from DFT-derived
    friction (Newns–Anderson style) and a harmonic frequency.

    Physics:
      DFT can provide a mode-projected electronic friction contribution, which
      can be reported as an energy broadening (eV). Combine catalyst and intrinsic
      contributions if needed.

    Math:
      χ = (Γ_total) / (2 h c ν̃)
      with Γ_total in eV, (h c) in eV·cm, and ν̃ in cm^-1.

    Args:
      gamma_cat_ev: Catalyst induced linewidth (eV). May be 0 for control cases.
      nu_cm1: Harmonic frequency (cm^-1)
      gamma_int_ev: Optional intrinsic gas-phase linewidth (eV)

    Returns:
      Dimensionless damping ratio χ
    """
    _require_nonnegative(gamma_cat_ev, "gamma_cat_ev")
    _require_positive(nu_cm1, "nu_cm1")
    _require_finite(gamma_int_ev, "gamma_int_ev")
    if gamma_int_ev < 0.0:
        raise ValueError(f"gamma_int_ev must be >= 0. Got {gamma_int_ev!r}")

    total_gamma_ev = gamma_cat_ev + gamma_int_ev
    return total_gamma_ev / (2.0 * HC_EV_CM * nu_cm1)


# =====================================================================
# TEST 8: Exact analytical p value (log-uniform prior)
# =====================================================================

@dataclass(frozen=True)
class Test8Result:
    p_single: float
    p_exact_N: float
    log10_p_exact_N: float

    def as_dict(self) -> Dict[str, float]:
        return {
            "p_single": self.p_single,
            "p_exact_N": self.p_exact_N,
            "log10_p_exact_N": self.log10_p_exact_N,
        }


def test8_p_value(
    n_optimal_systems: int,
    window_min: float = 0.8,
    window_max: float = 1.2,
    log10_chi_min: float = -4.0,
    log10_chi_max: float = 1.0,
) -> Test8Result:
    """
    Exact analytical falsification probability for Test 8.

    Assumption:
      χ is distributed log-uniformly over a physically plausible range:
      log10(χ) ~ Uniform[log10_chi_min, log10_chi_max].

    Let the "critical window" be [window_min, window_max] in χ.

    Then for one draw:
      p_single = width_in_log_space(window) / total_log_range

    For N independent optimal systems:
      p_exact = (p_single)^N

    Computed in log-space for numerical stability:
      log10(p_exact) = N * log10(p_single)

    Args:
      n_optimal_systems: N, number of independent optimal systems
      window_min: lower bound of critical window in χ
      window_max: upper bound of critical window in χ
      log10_chi_min: lower bound of physically allowed χ range in log10 space
      log10_chi_max: upper bound of physically allowed χ range in log10 space

    Returns:
      Test8Result with p_single, p_exact_N, and log10(p_exact_N)
    """
    if not isinstance(n_optimal_systems, int) or n_optimal_systems <= 0:
        raise ValueError(f"n_optimal_systems must be a positive int. Got {n_optimal_systems!r}")

    _require_positive(window_min, "window_min")
    _require_positive(window_max, "window_max")
    if window_max <= window_min:
        raise ValueError("window_max must be > window_min")

    _require_finite(log10_chi_min, "log10_chi_min")
    _require_finite(log10_chi_max, "log10_chi_max")
    if log10_chi_max <= log10_chi_min:
        raise ValueError("log10_chi_max must be > log10_chi_min")

    log_range = log10_chi_max - log10_chi_min
    window_width = log10(window_max) - log10(window_min)

    if window_width <= 0.0:
        raise ValueError("Critical window has non-positive width in log space.")

    p_single = window_width / log_range

    # Guard: if the window exceeds the full range, clamp at 1 (should not happen with sane inputs)
    if p_single > 1.0:
        p_single = 1.0

    log10_p_exact = n_optimal_systems * log10(p_single)
    p_exact = 10.0 ** log10_p_exact

    return Test8Result(p_single=p_single, p_exact_N=p_exact, log10_p_exact_N=log10_p_exact)


# =====================================================================
# Minimal verification block
# =====================================================================

def _demo() -> None:
    print("=== SYMC METHODS DEMO ===")

    # Route A example (wavenumber inputs, Lorentzian-only linewidth)
    chi_spec = chi_route_a(delta_nu_L_cm1=30.0, nu_cm1=1500.0)
    print(f"Route A (spectroscopy): χ = {chi_spec:.4f}")

    # Route B example
    chi_et = chi_route_b(tau_l_ps=0.2, lambda_ev=0.7, delta_q_angstrom=0.5, m_eff_amu=100.0)
    print(f"Route B (solvent ET):   χ = {chi_et:.4f}")

    # Route C example
    chi_dft = chi_route_c(gamma_cat_ev=0.45, nu_cm1=1415.0)
    print(f"Route C (DFT friction): χ = {chi_dft:.4f}")

    # Test 8 example
    res = test8_p_value(n_optimal_systems=4)
    print("Test 8:")
    print(f"  p_single      = {res.p_single:.6g}")
    print(f"  p_exact_N     = {res.p_exact_N:.6g}")
    print(f"  log10(p_exact)= {res.log10_p_exact_N:.6g}")


if __name__ == "__main__":
    _demo()