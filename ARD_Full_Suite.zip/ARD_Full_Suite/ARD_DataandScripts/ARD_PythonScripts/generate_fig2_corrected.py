"""
generate_fig2_corrected.py
Test 5: BEP Volcano Outliers Explained by Approach-Region Dynamical Efficiency

Fixes vs original:
  1. Removed google.colab import and files.download() calls
  2. Added matplotlib.use('Agg') for headless operation
  3. axvspan: [0.8, 1.2] -> [0.8, 1.3]; label updated to 'Near-critical band'
  4. K-Fe(111) chi: 1.3 -> 1.2825 (Route C: 0.45 eV / (2 * 1.23984e-4 eV*cm * 1415 cm^-1))
  5. x-axis label: Delta E / 2h*nu -> Gamma_NN / (2hc*nu) to match Route C notation
  6. Title updated to include 'Approach-Region'
  7. Annotation '$chi >> 1$' replaced with Unicode to stay editable in Illustrator
  8. Removed plt.show()
  9. 'Adaptive Window' terminology replaced with 'Near-critical band'
"""

import matplotlib
matplotlib.use('Agg')                          # FIX 2: headless backend

import numpy as np
import matplotlib.pyplot as plt

# FIX already present in original — keep
plt.rcParams['svg.fonttype'] = 'none'

# ── Predicted schematic curve ─────────────────────────────────────────────────
# Gaussian in log-chi space centred at chi=1; peaks at 1.0, schematic only
chi_vals = np.logspace(-3, 1.5, 500)
predicted_residual = np.exp(-0.5 * (np.log(chi_vals) / 0.8)**2)

fig, ax = plt.subplots(figsize=(11, 7))

ax.plot(chi_vals, predicted_residual, 'k--', linewidth=2, alpha=0.6,
        label='Predicted Dynamical Enhancement')

# FIX 3 & 9: window [0.8, 1.3] and updated label
ax.axvspan(0.8, 1.3, color='green', alpha=0.15,
           label=r'Near-critical band ($\chi \in [0.8, 1.3]$)')

# ── Real data points (N2/Fe surfaces, Route C) ───────────────────────────────
# FIX 4: K-Fe(111) chi = 1.2825 (Route C: Gamma=0.45 eV, nu=1415 cm^-1)
# Over-promoted Fe at chi=2.5 is schematic (no Route C value available)
real_metals_data = [
    (0.096, -0.30, 'Fe(111) unpromoted\n(Underdamped)',       '#1f77b4'),
    (0.605,  0.00, 'Fe(110)\n(BEP Baseline)',                 '#7f7f7f'),
    (1.2825, 0.85, 'Fe(111) K-promoted\n(Positive Outlier)',  '#2ca02c'),
    (2.50,  -0.50, 'Poisoned/Over-promoted Fe\n(Overdamped)', '#d62728'),
]

chi_pts = [d[0] for d in real_metals_data]
res_pts = [d[1] for d in real_metals_data]
labels  = [d[2] for d in real_metals_data]
colors  = [d[3] for d in real_metals_data]

ax.scatter(chi_pts, res_pts, c=colors, s=120, marker='D',
           edgecolor='black', zorder=5,
           label=r'Actual N$_2$/Fe Systems')

# ── Staggered label offsets ───────────────────────────────────────────────────
offsets = [(-45, -25), (40, 20), (55, 10), (-45, 25)]
for i, (x, y, name) in enumerate(zip(chi_pts, res_pts, labels)):
    ax.annotate(name, (x, y),
                textcoords='offset points', xytext=offsets[i % len(offsets)],
                ha='center', va='center', fontsize=10,
                color=colors[i], fontweight='bold')

# FIX 7: Unicode chi and >> so the annotation stays a text node in SVG
ax.annotate(
    'Excess dissipation\npushes \u03c7 \u226b 1',   # χ ≫ 1
    xy=(2.4, -0.45), xytext=(1.4, -0.15),
    arrowprops=dict(arrowstyle="->", color='#d62728', lw=1.5, ls='--'),
    ha='center', fontsize=10, color='#d62728', style='italic',
)

# ── Axes ──────────────────────────────────────────────────────────────────────
ax.set_xscale('log')
ax.set_xlim(1e-2, 5)
ax.set_ylim(-0.8, 1.2)

ax.text(1.5e-2, -0.7, 'Regulatory Stasis\n(Oscillatory Recrossing)',
        fontsize=11, style='italic', color='grey')
ax.text(4, -0.7, 'Regulatory Flow\n(Sluggish Decay)',
        fontsize=11, style='italic', color='grey', ha='right')

ax.axhline(0, color='grey', linewidth=1.5, linestyle='-', alpha=0.8,
           label='BEP Thermodynamic Prediction')

# FIX 5: x-axis label uses Route C notation Gamma_NN / (2hc nu)
ax.set_xlabel(
    r'Approach-region damping ratio $\chi \approx \Gamma_{NN}/(2hc\tilde{\nu})$  (Route C)',
    fontsize=13,
)
ax.set_ylabel('Relative Deviation from BEP Limit\n(Qualitative)', fontsize=14)

# FIX 6: title includes 'Approach-Region'
ax.set_title(
    'Test 5: BEP Volcano Outliers Explained by Approach-Region Dynamical Efficiency',
    fontsize=15, pad=15,
)

ax.grid(True, which="both", ls="--", alpha=0.3)
ax.legend(loc='upper left', fontsize=11, framealpha=0.9)

plt.tight_layout()

# FIX 1: no Colab calls — save locally
plt.savefig('/mnt/user-data/outputs/Fig2_FeBEPTest5.png',
            dpi=300, format='png', bbox_inches='tight')
plt.savefig('/mnt/user-data/outputs/Fig2_FeBEPTest5.svg',
            format='svg', bbox_inches='tight')
plt.close()                                    # FIX 8: no plt.show()
print("Fig2 saved.")
