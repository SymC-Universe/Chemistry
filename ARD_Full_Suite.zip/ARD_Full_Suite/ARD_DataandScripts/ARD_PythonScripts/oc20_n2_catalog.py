import requests, pickle, pandas as pd, os

OC20_MAPPING_URL = "https://dl.fbaipublicfiles.com/opencatalystproject/data/oc20_data_mapping.pkl"
mapping_file = "oc20_data_mapping.pkl"

# Download if not present
if not os.path.exists(mapping_file):
    print("Downloading OC20 mapping...")
    r = requests.get(OC20_MAPPING_URL)
    with open(mapping_file, "wb") as f:
        f.write(r.content)
    print("Download complete.")

# Load mapping
print("Loading mapping...")
with open(mapping_file, "rb") as f:
    mapping = pickle.load(f)

# Build N2 catalog
rows = []
for system_id, meta in mapping.items():
    ads = meta.get("ads_symbols")
    if isinstance(ads, str) and "N2" in ads:
        rows.append({
            "domain": "Catalysis",
            "system": f"OC20 {system_id} (*N2)",
            "chi_optimum": "",
            "uncertainty": "",
            "method": "OC20 mapping (chi TBD)",
            "notes": "Large catalysis cohort; attach chi proxy later",
            "ads_symbols": ads,
            "bulk_symbols": meta.get("bulk_symbols"),
            "miller_index": str(meta.get("miller_index")),
        })

df = pd.DataFrame(rows)
df.to_csv("oc20_n2_catalog.csv", index=False)

print("N2 systems:", len(df))
print("Saved: oc20_n2_catalog.csv")