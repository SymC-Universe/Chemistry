"""
test8_ClusterAudit.py
Test 8 cluster audit with corrected operational window [0.8, 1.3].

Corrections vs original:
  - w_max default: 1.2 -> 1.3
  - N: 3 (catalysis direct + ET structural + PCET mechanistic)
  - Added prospective status note
"""

import math


def test8_p_value(n_independent: int,
                  w_min: float = 0.8, w_max: float = 1.3,
                  log_min: float = -4.0, log_max: float = 1.0) -> dict:
    """
    Test 8 p-value under log-uniform prior.

    Args:
        n_independent: number of independently qualifying anchor systems
        w_min: lower bound of near-critical window (default 0.8)
        w_max: upper bound of near-critical window (default 1.3)
        log_min: log10 of lower prior bound (default -4)
        log_max: log10 of upper prior bound (default 1)

    Returns:
        dict with p_single_pct, log10_p, p_exact, significant
    """
    log_range   = log_max - log_min
    window_frac = math.log10(w_max) - math.log10(w_min)
    p_single    = window_frac / log_range
    log10_p     = n_independent * math.log10(p_single)

    return {
        "p_single_pct": round(p_single * 100, 4),
        "log10_p":       round(log10_p, 4),
        "p_exact":       10 ** log10_p,
        "significant":   log10_p < math.log10(0.05),
    }


# Three candidate anchor systems
n_systems = 3
results = test8_p_value(n_systems)

print("--- TEST 8: CROSS-DOMAIN CLUSTERING STATISTICAL AUDIT ---")
print(f"Candidate anchor systems (N={n_systems}):")
print("  1. Heterogeneous Catalysis -- Fe(111) K-promoted, chi_DFT = 1.2825 (Route C, direct)")
print("  2. Electron Transfer       -- PGH structural argument (turnover maximum near chi=1)")
print("  3. PCET                    -- near-zero activation volume, concerted regime (mechanistic)")
print("-------------------------------------------------------")
print(f"Near-critical window:                        [0.8, 1.3]")
print(f"Log-uniform prior:                           [1e-4, 1e1]")
print(f"P(single system in window by chance):        {results['p_single_pct']:.3f}%")
print(f"Combined p-value for N={n_systems}:                    {results['p_exact']:.2e}")
print(f"log10(p):                                    {results['log10_p']:.3f}")
print(f"Statistically significant (p < 0.05):        {results['significant']}")
print()
print("NOTE: Test 8 is prospective. Only the catalysis anchor provides a direct")
print("numerical chi estimate. Formal validation requires direct chi in all three domains.")
