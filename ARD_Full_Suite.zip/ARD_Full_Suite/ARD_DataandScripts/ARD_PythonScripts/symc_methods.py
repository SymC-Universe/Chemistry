"""
symc_methods.py  (previously stability_methods.py)

Computational methods for the SymC Critical Damping Framework.
Approach-Region Dynamics and Rate Turnover in Thermally Activated Barrier Crossing.

Corrections vs stability_methods.py:
  1. chi_route_b: gamma = 1/tau_L (WRONG) -> gamma = Omega_s^2 * tau_L (Debye-Drude)
     Physical basis: van der Zwan & Hynes (1982); slower solvents are MORE overdamped.
  2. Added chi_route_b_relative: preferred estimator for same-class solvent series.
  3. Added chi_route_b_absolute: correct absolute estimator with Omega_s parameter.
  4. Added chi_pcet_isotope: H->D raises chi (upper bound, proton-dominated limit).
  5. test8_p_value: window default [0.8, 1.2] -> [0.8, 1.3]; N default 4 -> 3.
  6. All Route C references use Gamma_NN (energy width, eV) not gamma_NN (rate).

Routes:
  A) chi_route_a         -- spectroscopic proxy from Lorentzian linewidth
  B) chi_route_b_relative -- preferred relative estimator (same-class solvents)
     chi_route_b_absolute -- absolute estimator (requires Omega_s)
  C) chi_route_c         -- DFT electronic friction (Newns-Anderson energy width)

Isotope:
     chi_pcet_isotope    -- H->D shift in proton-dominated limit

Test 8:
     test8_p_value       -- analytical p-value under log-uniform prior

Author: Nate Christensen (SymC Universe Project)
"""

from __future__ import annotations
from dataclasses import dataclass
from math import sqrt, log10, pi, isfinite
from typing import Dict

# ── Constants ──────────────────────────────────────────────────────────────────
EV_TO_JOULES: float = 1.602176634e-19       # J per eV (exact)
AMU_TO_KG:    float = 1.66053906660e-27     # kg per amu (CODATA 2018)
ANGSTROM_TO_M:float = 1.0e-10              # m per Angstrom
PS_TO_S:      float = 1.0e-12              # s per ps
HC_EV_CM:     float = 1.23984193e-4        # h*c in eV*cm
C_CM_PER_S:   float = 2.99792458e10        # speed of light in cm/s (NIST)


# ── Validation helpers ─────────────────────────────────────────────────────────
def _pos(x: float, name: str) -> None:
    if not isfinite(x) or x <= 0:
        raise ValueError(f"{name} must be finite and > 0. Got {x!r}")

def _nonneg(x: float, name: str) -> None:
    if not isfinite(x) or x < 0:
        raise ValueError(f"{name} must be finite and >= 0. Got {x!r}")


# ── ROUTE A: Spectroscopic proxy ───────────────────────────────────────────────
def chi_route_a(delta_nu_L_cm1: float, nu_cm1: float) -> float:
    """
    Spectroscopic proxy for chi_0 from Lorentzian linewidth.

    delta_nu_L_cm1 MUST be the Lorentzian-only FWHM (Voigt fit),
    not the raw instrument FWHM.

    chi = Delta_nu_L / (2 * nu)

    Args:
        delta_nu_L_cm1: Lorentzian FWHM in cm^-1
        nu_cm1:         Peak frequency in cm^-1

    Returns:
        Dimensionless chi_0
    """
    _pos(delta_nu_L_cm1, "delta_nu_L_cm1")
    _pos(nu_cm1, "nu_cm1")
    return delta_nu_L_cm1 / (2.0 * nu_cm1)


# ── ROUTE B: Solvent relaxation ────────────────────────────────────────────────
def chi_route_b_relative(tau_l_a_ps: float,
                          tau_l_b_ps: float,
                          omega_s_a_cm: float = None,
                          omega_s_b_cm: float = None) -> float:
    """
    Relative Route B estimator (preferred for same-class solvent series).

    chi_A / chi_B = (Omega_s_A^2 / Omega_s_B^2) * (tau_L_A / tau_L_B)

    For same-class solvents (comparable Omega_s), C_solv cancels and:
        chi_A / chi_B approx tau_L_A / tau_L_B

    For cross-class comparisons, supply omega_s_a_cm and omega_s_b_cm.

    Physical basis: Gamma = Omega_s^2 * tau_L (van der Zwan & Hynes 1982).
    Larger tau_L -> larger chi -> more overdamped. This is the CORRECTED
    direction; the inverse relation (chi ∝ 1/tau_L) was wrong.

    Args:
        tau_l_a_ps:    tau_L for solvent A in ps
        tau_l_b_ps:    tau_L for solvent B (reference) in ps
        omega_s_a_cm:  Solvent A Debye-Drude bath frequency in cm^-1 (optional)
        omega_s_b_cm:  Solvent B Debye-Drude bath frequency in cm^-1 (optional)

    Returns:
        chi_A / chi_B (dimensionless ratio)
    """
    _pos(tau_l_a_ps, "tau_l_a_ps")
    _pos(tau_l_b_ps, "tau_l_b_ps")
    ratio = tau_l_a_ps / tau_l_b_ps
    if omega_s_a_cm is not None and omega_s_b_cm is not None:
        _pos(omega_s_a_cm, "omega_s_a_cm")
        _pos(omega_s_b_cm, "omega_s_b_cm")
        ratio *= (omega_s_a_cm / omega_s_b_cm) ** 2
    return ratio


def chi_route_b_absolute(tau_l_ps: float,
                          lambda_ev: float,
                          delta_q_ang: float,
                          m_eff_amu: float,
                          omega_s_cm: float) -> float:
    """
    Absolute Route B estimator (for screening; large uncertainty).

    chi = (Omega_s^2 * tau_L) / (2 * Omega_0)
    Omega_0 = sqrt(2 * lambda / (m_eff * DeltaQ^2))

    CAUTION: Absolute values depend quadratically on Omega_s, which is a
    model-specific Debye-Drude parameter not directly the far-IR librational
    peak. Values can span an order of magnitude across plausible Omega_s.
    Use chi_route_b_relative for robust regime assignments.

    Args:
        tau_l_ps:    tau_L in ps
        lambda_ev:   reorganization energy in eV
        delta_q_ang: coordinate displacement in Angstrom
        m_eff_amu:   effective mass in amu
        omega_s_cm:  Debye-Drude bath frequency in cm^-1

    Returns:
        Absolute chi_0 (approach-region estimate; use with caution)
    """
    _pos(tau_l_ps,    "tau_l_ps")
    _pos(lambda_ev,   "lambda_ev")
    _pos(delta_q_ang, "delta_q_ang")
    _pos(m_eff_amu,   "m_eff_amu")
    _pos(omega_s_cm,  "omega_s_cm")

    tau_s    = tau_l_ps    * PS_TO_S
    lam_j    = lambda_ev   * EV_TO_JOULES
    dq_m     = delta_q_ang * ANGSTROM_TO_M
    m_kg     = m_eff_amu   * AMU_TO_KG
    omega_s  = omega_s_cm  * 2 * 3.14159265358979 * C_CM_PER_S  # rad/s

    omega_0  = sqrt(2.0 * lam_j / (m_kg * dq_m ** 2))
    gamma    = omega_s ** 2 * tau_s

    return gamma / (2.0 * omega_0)


# ── ROUTE C: DFT electronic friction ──────────────────────────────────────────
def chi_route_c(gamma_nn_ev: float,
                nu_cm1: float,
                gamma_int_ev: float = 0.0) -> float:
    """
    Route C: approach-region chi from Newns-Anderson energy broadening.

    chi_DFT = (Gamma_NN + Gamma_int) / (2 * h*c * nu)

    Gamma_NN is the Newns-Anderson hybridization energy WIDTH (eV),
    not a vibrational friction coefficient. The formula is a ratio
    of two energies and is exactly dimensionless.

    Args:
        gamma_nn_ev:  Newns-Anderson energy broadening Gamma_NN in eV
        nu_cm1:       Harmonic adsorbate frequency in cm^-1
        gamma_int_ev: Intrinsic gas-phase broadening in eV (default 0)

    Returns:
        Dimensionless chi_0 (ground-state approach-region estimate;
        lower bound when reactive bond softens toward TS)
    """
    _nonneg(gamma_nn_ev,  "gamma_nn_ev")
    _pos(nu_cm1,          "nu_cm1")
    _nonneg(gamma_int_ev, "gamma_int_ev")
    return (gamma_nn_ev + gamma_int_ev) / (2.0 * HC_EV_CM * nu_cm1)


# ── PCET ISOTOPE SHIFT ─────────────────────────────────────────────────────────
def chi_pcet_isotope(chi_H: float) -> float:
    """
    H -> D isotope shift in the proton-dominated limit.

    chi_D = sqrt(2) * chi_H  (upper bound)

    H->D doubles the proton mass, lowers Omega_0 by sqrt(2), and raises chi.
    This is an UPPER BOUND: solvent-dressed coordinates show a smaller shift
    because collective reorganization mass dilutes the proton contribution.
    The qualitative direction (D raises chi) is model-independent.

    Args:
        chi_H: approach-region chi for the protiated system

    Returns:
        chi_D upper bound
    """
    _pos(chi_H, "chi_H")
    return sqrt(2.0) * chi_H


# ── TEST 8: Cross-domain clustering p-value ────────────────────────────────────
@dataclass(frozen=True)
class Test8Result:
    p_single:      float
    p_exact_N:     float
    log10_p:       float
    n_systems:     int
    window:        tuple

    def as_dict(self) -> Dict:
        return {
            "n_systems":  self.n_systems,
            "window":     self.window,
            "p_single":   self.p_single,
            "p_exact_N":  self.p_exact_N,
            "log10_p":    self.log10_p,
        }


def test8_p_value(n_independent: int = 3,
                  window_min: float = 0.8,
                  window_max: float = 1.3,
                  log10_chi_min: float = -4.0,
                  log10_chi_max: float = 1.0) -> Test8Result:
    """
    Exact analytical p-value for Test 8 (log-uniform prior).

    p_single = log10(window_max/window_min) / (log10_chi_max - log10_chi_min)
    p_exact  = p_single ^ n_independent

    Default window [0.8, 1.3] matches the manuscript operational band.
    Default N=3: catalysis (direct), ET (structural), PCET (mechanistic).

    Test 8 is prospective until all three domains have direct chi estimates.

    Args:
        n_independent:  number of candidate anchor systems (default 3)
        window_min:     near-critical window lower bound (default 0.8)
        window_max:     near-critical window upper bound (default 1.3)
        log10_chi_min:  log10 of prior lower bound (default -4)
        log10_chi_max:  log10 of prior upper bound (default 1)

    Returns:
        Test8Result with p_single, p_exact_N, log10_p
    """
    if not isinstance(n_independent, int) or n_independent <= 0:
        raise ValueError(f"n_independent must be a positive int. Got {n_independent!r}")
    _pos(window_min, "window_min")
    _pos(window_max, "window_max")
    if window_max <= window_min:
        raise ValueError("window_max must be > window_min")

    log_range    = log10_chi_max - log10_chi_min
    window_width = log10(window_max) - log10(window_min)
    p_single     = min(window_width / log_range, 1.0)
    log10_p      = n_independent * log10(p_single)

    return Test8Result(
        p_single  = p_single,
        p_exact_N = 10.0 ** log10_p,
        log10_p   = log10_p,
        n_systems = n_independent,
        window    = (window_min, window_max),
    )


# ── Demo ───────────────────────────────────────────────────────────────────────
def _demo() -> None:
    print("=== SYMC METHODS DEMO ===\n")

    chi_a = chi_route_a(30.0, 1500.0)
    print(f"Route A (spectroscopic):    chi = {chi_a:.4f}")

    chi_b_rel = chi_route_b_relative(0.80, 0.20)
    print(f"Route B (relative THF/MeCN): chi_rel = {chi_b_rel:.2f}x  "
          f"(THF more overdamped)")

    chi_b_abs = chi_route_b_absolute(0.20, 0.7, 0.5, 100.0, 100.0)
    print(f"Route B (absolute MeCN):    chi = {chi_b_abs:.3f}  "
          f"(screening only; large Omega_s uncertainty)")

    chi_c = chi_route_c(0.45, 1415.0)
    print(f"Route C K-Fe(111):          chi = {chi_c:.4f}  "
          f"(near-critical, inside [0.8, 1.3])")

    chi_d = chi_pcet_isotope(0.90)
    print(f"PCET H->D (chi_H=0.90):     chi_D = {chi_d:.4f}  "
          f"(upper bound)")

    res = test8_p_value(n_independent=3)
    print(f"\nTest 8 (N=3, window=[0.8,1.3]):")
    print(f"  p_single = {res.p_single*100:.3f}%")
    print(f"  p_N3     = {res.p_exact_N:.2e}")
    print(f"  log10(p) = {res.log10_p:.3f}")
    print(f"  (prospective — catalysis anchor only has direct chi)")


if __name__ == "__main__":
    _demo()
