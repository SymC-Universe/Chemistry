"""
generate_fig3_corrected.py
Standard-State Lattice chi Map at 298 K — corrected source.

Fixes applied vs original:
  1. Fe  lambda_ep: 0.90 → 0.47   (McMillan 1968)
  2. Ni  lambda_ep: 0.40 → 0.72, Theta_D: 450 → 375  (McMillan 1968)
  3. Pd  lambda_ep: 0.41 → 0.90, Theta_D: 274 → 275  (McMillan 1968)
  4. V   lambda_ep: 0.82 → 0.60, Theta_D: 380 → 273  (McMillan 1968)
  5. Nb  lambda_ep: 1.05 → 1.33   (McMillan 1968)
  6. axhspan bounds: [0.8, 1.2] → [0.8, 1.3]  (manuscript v10 window)
  7. Legend label: 'Critical Window [0.8, 1.2]' → 'Near-critical band [0.8, 1.3]'
  8. chi=1 text label updated to match figure: '$\chi = 1$  ($10^0$ line)'
  9. chi=1 label x-position moved to avoid legend overlap
 10. plt.show() removed; matplotlib backend set to Agg for headless operation
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')                    # FIX 10: headless backend
import matplotlib.pyplot as plt
import matplotlib.patheffects as path_effects

print("--- GENERATING CORRECTED 118-ELEMENT CHI MAP ---")

# =====================================================================
# 1. PHYSICAL REFERENCE LIBRARY  (Z=1 to Z=94, McMillan/Allen-Dynes)
# =====================================================================
known_physics = {
    # s-block
    1:  (100,  0.001, "H"),  3:  (344,  0.40,  "Li"),  4:  (1440, 0.24,  "Be"),
    11: (150,  0.15,  "Na"), 12: (400,  0.30,  "Mg"), 19: (91,   0.13,  "K"),
    20: (230,  0.20,  "Ca"), 37: (56,   0.16,  "Rb"), 38: (147,  0.20,  "Sr"),
    55: (38,   0.16,  "Cs"), 56: (110,  0.20,  "Ba"), 87: (30,   0.15,  "Fr"),
    88: (90,   0.20,  "Ra"),

    # p-block noble gases
    2:  (25,   1e-6,  "He"), 10: (75,   1e-6,  "Ne"), 18: (92,   1e-6,  "Ar"),
    36: (72,   1e-6,  "Kr"), 54: (64,   1e-6,  "Xe"), 86: (35,   1e-6,  "Rn"),

    # p-block nonmetals / halogens / metalloids
    5:  (1200, 0.01,  "B"),  6:  (2200, 0.001, "C"),  7:  (70,   0.001, "N"),
    8:  (104,  0.001, "O"),  9:  (100,  0.001, "F"),  14: (645,  0.005, "Si"),
    15: (280,  0.002, "P"),  16: (105,  0.003, "S"),  17: (130,  0.001, "Cl"),
    33: (282,  0.05,  "As"), 34: (90,   0.01,  "Se"), 35: (116,  0.001, "Br"),
    52: (153,  0.10,  "Te"), 53: (109,  0.001, "I"),  85: (85,   0.001, "At"),

    # p-block metals
    13: (428,  0.43,  "Al"), 31: (320,  0.45,  "Ga"), 32: (374,  0.05,  "Ge"),
    49: (108,  0.80,  "In"), 50: (200,  0.72,  "Sn"), 51: (200,  0.20,  "Sb"),
    81: (78,   0.79,  "Tl"), 82: (105,  1.55,  "Pb"), 83: (119,  0.50,  "Bi"),
    84: (169,  0.60,  "Po"),

    # d-block  — FIX 1,2,3,4,5: corrected McMillan 1968 values
    21: (345,  0.45,  "Sc"), 22: (420,  0.54,  "Ti"),
    23: (273,  0.60,  "V"),   # FIX 4: Theta_D 380→273, lambda 0.82→0.60
    24: (610,  0.20,  "Cr"), 25: (400,  0.40,  "Mn"),
    26: (470,  0.47,  "Fe"),  # FIX 1: lambda 0.90→0.47
    27: (445,  0.40,  "Co"),
    28: (375,  0.72,  "Ni"),  # FIX 2: lambda 0.40→0.72, Theta_D 450→375
    29: (343,  0.15,  "Cu"), 30: (327,  0.42,  "Zn"),
    39: (280,  0.65,  "Y"),  40: (290,  0.60,  "Zr"),
    41: (275,  1.33,  "Nb"), # FIX 5: lambda 1.05→1.33
    42: (450,  0.40,  "Mo"), 43: (400,  0.65,  "Tc"),
    44: (600,  0.40,  "Ru"), 45: (480,  0.45,  "Rh"),
    46: (275,  0.90,  "Pd"), # FIX 3: lambda 0.41→0.90, Theta_D 274→275
    47: (225,  0.13,  "Ag"), 48: (209,  0.40,  "Cd"),
    72: (252,  0.45,  "Hf"), 73: (240,  0.60,  "Ta"),
    74: (400,  0.28,  "W"),  75: (430,  0.45,  "Re"),
    76: (500,  0.40,  "Os"), 77: (420,  0.45,  "Ir"),
    78: (240,  0.50,  "Pt"), 79: (165,  0.14,  "Au"),
    80: (71,   1.60,  "Hg"),

    # f-block up to Z=94
    57: (145,  0.75,  "La"), 58: (150,  0.60,  "Ce"), 59: (152,  0.40,  "Pr"),
    60: (163,  0.40,  "Nd"), 61: (160,  0.40,  "Pm"), 62: (169,  0.40,  "Sm"),
    63: (118,  0.40,  "Eu"), 64: (176,  0.55,  "Gd"), 65: (158,  0.40,  "Tb"),
    66: (183,  0.40,  "Dy"), 67: (190,  0.40,  "Ho"), 68: (188,  0.40,  "Er"),
    69: (200,  0.40,  "Tm"), 70: (118,  0.30,  "Yb"), 71: (166,  0.40,  "Lu"),
    89: (160,  0.50,  "Ac"), 90: (163,  0.54,  "Th"), 91: (185,  0.52,  "Pa"),
    92: (200,  0.53,  "U"),  93: (190,  0.60,  "Np"), 94: (163,  0.65,  "Pu"),
}

# Explicit symbols for selected synthetics (Z > 94)
synthetic_labels = {
    95: "Am", 103: "Lr", 104: "Rf", 112: "Cn", 114: "Fl", 118: "Og"
}

# =====================================================================
# 2. GENERATE ALL 118 ELEMENTS
# =====================================================================
def get_block(z):
    if z in [1, 2, 3, 4, 11, 12, 19, 20, 37, 38, 55, 56, 87, 88]:
        return 's'
    if (21 <= z <= 30) or (39 <= z <= 48) or (72 <= z <= 80) or (104 <= z <= 112):
        return 'd'
    if (57 <= z <= 71) or (89 <= z <= 103):
        return 'f'
    return 'p'

elements_data = []
for z in range(1, 119):
    block = get_block(z)
    if z in known_physics:
        theta_d, lam_ep, symbol = known_physics[z]
        is_anchor = True
    else:
        symbol   = synthetic_labels.get(z, f"Z={z}")
        is_anchor = z in synthetic_labels
        # Block-average proxies apply only to Z > 94 synthetics
        if   block == 's': theta_d, lam_ep = 150.0, 0.20
        elif block == 'p': theta_d, lam_ep = 180.0, 0.80
        elif block == 'd': theta_d, lam_ep = 300.0, 0.45
        else:              theta_d, lam_ep = 150.0, 0.50   # f-block
    elements_data.append({
        "Z": z, "Symbol": symbol, "Block": block,
        "Debye_Temp": theta_d, "lambda_ep": lam_ep, "is_anchor": is_anchor,
    })

df = pd.DataFrame(elements_data)

# =====================================================================
# 3. CALCULATE chi_lattice = pi * lambda_ep * T / (2 * Theta_D)
# =====================================================================
T_kelvin = 298.15
df["chi"] = (np.pi * df["lambda_ep"] * T_kelvin) / (2.0 * df["Debye_Temp"])

# Print verification table for key elements
print("\nKey element verification (McMillan-corrected):")
print(f"{'Sym':>4}  {'lambda':>7}  {'Theta_D':>8}  {'chi':>8}  {'regime':>12}")
for sym, z in [("Fe",26),("Co",27),("Ni",28),("V",23),("Nb",41),("Pd",46),
               ("Pt",78),("Pb",82),("Hg",80)]:
    row = df[df["Z"]==z].iloc[0]
    regime = "near-crit" if 0.8<=row.chi<=1.3 else ("over" if row.chi>1.3 else "under")
    print(f"  {sym:>4}  {row.lambda_ep:>7.3f}  {row.Debye_Temp:>8.1f}  "
          f"{row.chi:>8.4f}  {regime:>12}")

near = df[(df["chi"]>=0.8)&(df["chi"]<=1.3)]
print(f"\nNear-critical elements [0.8, 1.3]: {len(near)}")
print(near[["Z","Symbol","Block","chi"]].to_string(index=False))

# =====================================================================
# 4. DARK-MODE PLOT
# =====================================================================
plt.style.use('dark_background')
fig, ax = plt.subplots(figsize=(15, 8.5))
fig.patch.set_facecolor('#0d1117')
ax.set_facecolor('#0d1117')

colors = {'s': '#ffb703', 'p': '#00f5d4', 'd': '#f15bb5', 'f': '#9d4edd'}

# FIX 6 & 7: operational band now [0.8, 1.3] to match manuscript
ax.axhspan(0.8, 1.3, color='#00f5d4', alpha=0.10, zorder=0,
           label=r"Near-critical band [0.8, 1.3]")
ax.axhline(1.0, color='#00f5d4', linestyle='--', linewidth=1.5, alpha=0.8, zorder=1)

# FIX 8 & 9: correct label text and position (use axes coords to avoid overlap)
ax.text(0.985, 1.0, r'$\chi = 1$  ($10^0$ line)',
        transform=ax.get_yaxis_transform(),
        verticalalignment='center', horizontalalignment='right',
        fontweight='bold', color='#00f5d4', fontsize=11, zorder=6)

# Plot with glow effect
for block in ['s', 'p', 'd', 'f']:
    sub = df[df['Block'] == block]
    c = colors[block]
    ax.scatter(sub["Z"], sub["chi"], color=c, s=300, alpha=0.05,
               edgecolors='none', zorder=2)
    ax.scatter(sub["Z"], sub["chi"], color=c, s=100, alpha=0.20,
               edgecolors='none', zorder=2)
    ax.scatter(sub["Z"], sub["chi"], color=c, s=40,  alpha=0.90,
               edgecolors='white', linewidth=0.8, label=f"{block}-block", zorder=3)

# ── Labels (75 selected elements) ─────────────────────────────────────────────
labels_to_plot = [
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
    11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
    22, 23, 24, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38,
    41, 42, 46, 47, 48, 50, 51, 52, 53, 54, 55, 56,
    57, 58, 64, 70, 71, 72, 73, 74, 78, 79, 80, 81, 82, 83, 84, 85, 86,
    88, 90, 92, 94, 95, 103, 104, 112, 114, 118,
]

for _, row in df.iterrows():
    if int(row["Z"]) not in labels_to_plot:
        continue
    z   = int(row["Z"])
    chi = row["chi"]

    if chi < 1e-2:
        y_offset = [1.5, 0.65, 1.9, 0.45][z % 4]
    elif chi > 1.0:
        y_offset = [1.15, 0.85, 1.25, 0.75][z % 4]
    else:
        y_offset = [1.18, 0.82, 1.28, 0.72][z % 4]

    txt = ax.text(z + 0.3, chi * y_offset, row["Symbol"],
                  fontsize=9, fontweight='bold', color='white', zorder=4)
    txt.set_path_effects([path_effects.Stroke(linewidth=2.5, foreground='black'),
                          path_effects.Normal()])

# Explanation box for synthetic flat lines
props = dict(boxstyle='round,pad=0.5', facecolor='#161b22',
             edgecolor='#444c56', alpha=0.9)
ax.text(0.02, 0.95,
        "Note: Elements Z > 94 (e.g., Am, Cn, Og) are fleeting synthetics.\n"
        "Lacking bulk thermodynamic data, they are plotted here\n"
        "as flat, block-average proxies.",
        transform=ax.transAxes, fontsize=11, verticalalignment='top',
        color='lightgray', bbox=props, zorder=5)

# ── Axes formatting ────────────────────────────────────────────────────────────
ax.set_yscale("log")
ax.set_xlim(0, 128)
ax.set_ylim(1e-6, 50)
ax.set_xlabel("Atomic Number (Z)", fontsize=14, fontweight='bold',
              labelpad=10, color='lightgray')
ax.set_ylabel(r"Physical Damping Ratio $\chi$ (log)", fontsize=14,
              fontweight='bold', labelpad=10, color='lightgray')
ax.set_title(r"Standard-State Lattice $\chi$ Map at 298 K",
             fontsize=18, fontweight='bold', color='white', pad=15)

ax.grid(True, which="major", axis="y",  color='white', linestyle='-',
        linewidth=0.5, alpha=0.15)
ax.grid(True, which="minor", axis="y",  color='white', linestyle=':',
        linewidth=0.5, alpha=0.05)
ax.grid(True, which="major", axis="x",  color='white', linestyle='--',
        linewidth=0.5, alpha=0.10)

ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['left'].set_color('#444c56');   ax.spines['left'].set_linewidth(1.5)
ax.spines['bottom'].set_color('#444c56'); ax.spines['bottom'].set_linewidth(1.5)

legend = ax.legend(loc='lower right', fontsize=12,
                   facecolor='#0d1117', edgecolor='#444c56', framealpha=0.9)
for text in legend.get_texts():
    text.set_color("white")

plt.tight_layout()
plt.savefig("/mnt/user-data/outputs/Fig3_Elemental_Map.png",
            dpi=300, facecolor='#0d1117', bbox_inches='tight')
plt.savefig("/mnt/user-data/outputs/Fig3_Elemental_Map.svg",
            format='svg', facecolor='#0d1117', bbox_inches='tight')
plt.close()
print("\nFigure saved: Fig3_Elemental_Map.png / .svg")
