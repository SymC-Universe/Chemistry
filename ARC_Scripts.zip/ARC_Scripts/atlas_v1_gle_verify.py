"""
atlas_v1_gle_verify.py
Verifies the GLE derivation: Gamma_eff = Omega_s^2 * tau_L

The manuscript (Section 2, Scope and Limitations) derives this from the
Ornstein-Uhlenbeck memory kernel K(t) = Omega_s^2 * exp(-t/tau_L).
In the Markovian limit: Gamma_eff = integral_0^inf K(t) dt = Omega_s^2 * tau_L

This script:
  1. Verifies the analytic result by numerical integration
  2. Confirms chi_0 from the GLE integral matches the Route B formula
  3. Shows the kernel converges by t ~ 5*tau_L (practical Markovian window)

References:
  Zusman 1980 Chem. Phys. 49, 295
  Hynes 1986 J. Phys. Chem. 90, 3701
  Bagchi, Oxtoby, Fleming 1984 Chem. Phys. 86, 257

Run in Google Colab: !python atlas_v1_gle_verify.py
"""

import math
import numpy as np

# ── CONSTANTS ─────────────────────────────────────────────────────
C_CM_S    = 2.99792458e10
EV_TO_J   = 1.602176634e-19
AMU_TO_KG = 1.66053906660e-27
ANG_TO_M  = 1e-10
PS_TO_S   = 1e-12

SEP = "─" * 62

print("=" * 62)
print("GLE DERIVATION VERIFICATION")
print("Gamma_eff = integral_0^inf K(t) dt = Omega_s^2 * tau_L")
print("=" * 62)
print()
print("Memory kernel: K(t) = Omega_s^2 * exp(-t / tau_L)")
print()
print("Analytic integral:")
print("  integral_0^inf Omega_s^2 * exp(-t/tau_L) dt = Omega_s^2 * tau_L")
print()

# ── NUMERICAL VERIFICATION ────────────────────────────────────────
# Fe(CN)6/MeCN central parameters
TAU_L  = 0.20e-12    # s
WS_CM1 = 100.0       # cm^-1
WS_RAD = WS_CM1 * 2 * math.pi * C_CM_S  # rad/s

# Integrate K(t) numerically from 0 to 50*tau_L
t_arr = np.linspace(0, 50 * TAU_L, 200000)
K_arr = WS_RAD**2 * np.exp(-t_arr / TAU_L)

Geff_numerical = np.trapezoid(K_arr, t_arr)   # NumPy 2.0 API
Geff_analytic  = WS_RAD**2 * TAU_L
rel_error = abs(Geff_numerical - Geff_analytic) / Geff_analytic

print(f"Parameters: tau_L = {TAU_L*1e12:.2f} ps, Omega_s = {WS_CM1:.0f} cm-1")
print(f"  Omega_s (rad/s):     {WS_RAD:.4e}")
print(f"  Analytic  Gamma_eff: {Geff_analytic:.6e} s^-1")
print(f"  Numerical Gamma_eff: {Geff_numerical:.6e} s^-1")
print(f"  Relative error:      {rel_error:.2e}")
print(f"  [{'PASS' if rel_error < 1e-4 else 'FAIL'}] Numerical matches analytic (tol 1e-4)")
print()

# ── CONFIRM CHI_0 CONSISTENCY ─────────────────────────────────────
LAM = 0.68; DQ = 0.40; M = 150.0

lam_j = LAM * EV_TO_J
dq_m  = DQ  * ANG_TO_M
m_kg  = M   * AMU_TO_KG
w0    = math.sqrt(2 * lam_j / (m_kg * dq_m**2))

chi_GLE     = Geff_numerical / (2 * w0)
chi_formula = (WS_RAD**2 * TAU_L) / (2 * w0)

print(f"  chi_0 from GLE integral: {chi_GLE:.5f}")
print(f"  chi_0 from formula:      {chi_formula:.5f}")
print(f"  [{'PASS' if abs(chi_GLE - chi_formula)/chi_formula < 1e-4 else 'FAIL'}] "
      f"GLE and formula agree for Fe(CN)6/MeCN")
print(f"  Central manuscript value: 1.52")
print()

# ── KERNEL CONVERGENCE ────────────────────────────────────────────
print(SEP)
print("KERNEL CONVERGENCE: fraction captured by t < N*tau_L")
print(SEP)
print()
for n_tau in [1, 2, 3, 5, 10]:
    mask = t_arr <= n_tau * TAU_L
    frac = np.trapezoid(K_arr[mask], t_arr[mask]) / Geff_analytic * 100
    print(f"  t < {n_tau:2d}*tau_L: {frac:.4f}% of Gamma_eff captured")

print()
print("The kernel is exhausted by t ~ 5*tau_L.")
print("This confirms the Markovian approximation quality:")
print("  if tau_L << reaction timescale, the integral is well-converged")
print("  before the reaction coordinate moves appreciably.")
print()
print("ALL GLE VERIFICATION TESTS COMPLETE.")
