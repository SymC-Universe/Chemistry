"""atlas_v1_rrkm.py — RRKM connection verification for Atlas_Main_v1.tex"""
import math

def eta(x): return 2*x/(1+x**2)
def chi_a(dnu,nu): return dnu/(2*nu)

print("RRKM--ARD CONNECTION")
print("-"*55)
print(f"P_commit = eta(chi) = 2chi/(1+chi^2)")
print()
for chi in [1e-3, 1e-2, 1e-1, 0.5, 1.0]:
    P = eta(chi)
    N = 1/P
    approx_err = abs(P - 2*chi)/(2*chi)*100
    print(f"  chi={chi:.4f}  P_commit={P:.5f}  N_encounters={N:.0f}  "
          f"approx_err(2chi)={approx_err:.3f}%")

print()
print("Gas-phase systems:")
for name, chi in [("Cyclopropane", chi_a(8,1070)),
                  ("NO2",          chi_a(10,800)),
                  ("CH3NC",        chi_a(1.77,460))]:
    P = eta(chi)
    print(f"  {name}: chi={chi:.5f}  P_commit={P:.5f}  N_encounters={1/P:.0f}")

print()
print("Gas/liquid chi ratio:")
chi_gas = chi_a(8, 1070)   # cyclopropane
chi_liq = 1.6296           # t-BuCl/H2O
print(f"  chi_gas(cyclopropane) = {chi_gas:.5f}")
print(f"  chi_liq(t-BuCl/H2O)  = {chi_liq:.4f}")
print(f"  Ratio = {chi_liq/chi_gas:.0f}x  = {math.log10(chi_liq/chi_gas):.2f} decades")
