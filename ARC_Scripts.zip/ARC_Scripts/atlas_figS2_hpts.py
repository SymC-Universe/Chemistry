"""
atlas_figS2_hpts.py
HPTS H/D isotope ratio: bifurcated perturbation (Supplementary Figure S2)

Shows the two independent contributions to the D/H ratio in HPTS Route B:
  1. Proton mass effect:     sqrt(m_D / m_H) = sqrt(2.014/1.008) = 1.414
  2. Solvent τ_L isotope:    τ_L(D₂O) / τ_L(H₂O) = 0.44/0.28   = 1.571
  Combined D/H ratio:        1.414 × 1.571                        = 2.221

The combined ratio exceeds the proton-mass-only ARD upper bound (√2 = 1.414).
This is physical: the solvent isotope effect on τ_L is larger than √2.

Key result: the ratio is INDEPENDENT of the absolute Route B bracket because
both H and D calculations use the same collective-shell assumptions
(m_eff_shell, ΔQ, λ, Ω_s), which cancel. Only the measured τ_L and the
explicitly substituted nucleus mass vary.

Verified in atlas_v1_verify_final.py (Test T7.3, T7.4).

Run in Google Colab:  !python atlas_figS2_hpts.py
Saves:  Atlas_FigS2_HPTS.svg  and  Atlas_FigS2_HPTS.png
"""

import math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ── COLAB-AWARE SAVE WITH EDITABLE SVG TEXT ───────────────────────
# svg.fonttype = 'none' writes SVG <text> elements instead of path
# outlines. Labels open as editable text strings in Adobe Illustrator.
plt.rcParams['svg.fonttype'] = 'none'

import os as _os

def _save_fig(basename):
    """Save SVG (editable text) and PNG (300 dpi).
    Detects Google Colab and saves to /content/ so files appear
    in the Colab file browser (left panel) for download.
    """
    try:
        import google.colab          # noqa: F401
        out_dir = '/content'
        _in_colab = True
    except ImportError:
        out_dir = _os.getcwd()
        _in_colab = False

    svg_out = _os.path.join(out_dir, basename + '.svg')
    png_out = _os.path.join(out_dir, basename + '.png')

    plt.savefig(svg_out, bbox_inches='tight')
    plt.savefig(png_out, bbox_inches='tight', dpi=300)

    print(f"Saved SVG: {svg_out}  (text editable in Illustrator)")
    print(f"Saved PNG: {png_out}  (300 dpi)")

    if _in_colab:
        print("Download: right-click the file in the Colab file browser,")
        print("  or run:  from google.colab import files")
        print(f" files.download('{svg_out}')")


# ── STYLE ─────────────────────────────────────────────────────────
plt.rcParams.update({
    'svg.fonttype': 'none',   # keeps text editable in Illustrator
    'font.family':     'serif',
    'font.size':       10,
    'axes.linewidth':  0.8,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
})

# ── CONSTANTS ─────────────────────────────────────────────────────
M_H       = 1.008    # amu, proton
M_D       = 2.014    # amu, deuteron
TAU_H2O   = 0.28     # ps, longitudinal relaxation time H₂O (Jimenez 1994)
TAU_D2O   = 0.44     # ps, longitudinal relaxation time D₂O (Jimenez 1994)

mass_ratio  = math.sqrt(M_D / M_H)           # proton mass contribution only
tauL_ratio  = TAU_D2O / TAU_H2O              # solvent τ_L isotope contribution
combined    = mass_ratio * tauL_ratio         # total D/H ratio
sqrt2       = math.sqrt(2)                    # ARD proton-mass-only upper bound

print(f"Proton mass factor:   sqrt(m_D/m_H) = {mass_ratio:.4f}")
print(f"Solvent τ_L factor:   τ_D/τ_H       = {tauL_ratio:.4f}")
print(f"Combined D/H ratio:                  = {combined:.4f}")
print(f"ARD upper bound √2:                  = {sqrt2:.4f}")
print(f"Combined > √2 bound: {combined > sqrt2}")

# ── FIGURE ────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(5.8, 4.4))

bars = [
    ('Proton mass only'             + '\n' + '√(mₜ/mʜ)',
     mass_ratio,  '#3a7dc9'),
    ('Solvent τₗ isotope'       + '\n' + 'τₗ(D) / τₗ(H)',
     tauL_ratio,  '#3a7dc9'),
    (r'Combined D/H ratio',
     combined,    '#3a7dc9'),
    ('ARD upper bound √2',
     sqrt2,       '#aaaaaa'),
]

for i, (lbl, val, col) in enumerate(bars):
    alpha = 0.85 if col != '#aaaaaa' else 0.55
    ax.bar(i, val, 0.60, color=col, alpha=alpha,
           ec='white', lw=0.5, zorder=3)
    num_col = '#1a4f8a' if col != '#aaaaaa' else '#555555'
    ax.text(i, val + 0.04, f'{val:.3f}',
            ha='center', va='bottom',
            fontsize=11, fontweight='bold', color=num_col)

# √2 reference line
ax.axhline(sqrt2, color='#4a90d9', lw=1.4, ls='--', alpha=0.8,
           label=f'√2 = {sqrt2:.3f} (proton-mass-only bound)')
ax.axhline(1.0, color='#cccccc', lw=0.8, ls=':')

ax.set_xticks(range(4))
ax.set_xticklabels([b[0] for b in bars], fontsize=9.5, fontfamily='Cambria Math')
ax.set_ylabel(r'Ratio relative to H$_2$O baseline', fontsize=10.5)
ax.set_ylim(0, 2.70)
ax.set_xlim(-0.5, 3.5)
ax.legend(fontsize=9, loc='upper left', framealpha=0.85)

ax.set_title('HPTS H/D isotope ratio: bifurcated perturbation',
             fontsize=11, fontweight='bold')

# Caption text inside figure
ax.text(0.50, 0.09,
        'The solvent isotope effect multiplies, rather than replaces,\n'
        r'the proton-mass contribution. The combined ratio (2.221) exceeds'
        '\n'
        '√2 because τₗ(D₂O)/τₗ(H₂O)'
        ' = 1.571 > √2.'
        '\n'
        'The ratio is independent of the absolute Route B bracket\n'
        '(shared collective-shell assumptions cancel; see Supp. S7).',
        transform=ax.transAxes, ha='center', fontsize=8.5, va='bottom',
        color='#333333', style='italic', linespacing=1.5)

plt.tight_layout(pad=1.0)

# ── SAVE ──────────────────────────────────────────────────────────
_save_fig('Atlas_FigS2_HPTS')
