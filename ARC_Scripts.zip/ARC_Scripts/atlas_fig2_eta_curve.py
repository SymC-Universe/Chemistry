"""
atlas_fig2_eta_curve.py
Approach-region dynamical efficiency landscape (Figure 2)

Plots η(χ₀) = 2χ₀/(1+χ₀²) on log scale with all nine atlas systems
overlaid at their central χ₀ values.

Y-axis label: "Schematic dynamical efficiency projection" — not normalized
experimental performance. Marker shape = evidence grade.

Run in Google Colab:  !python atlas_fig2_eta_curve.py
Saves:  Atlas_Fig2_EtaCurve.svg  and  Atlas_Fig2_EtaCurve.png
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ── COLAB-AWARE SAVE WITH EDITABLE SVG TEXT ───────────────────────
# svg.fonttype = 'none' writes SVG <text> elements instead of path
# outlines. Labels open as editable text strings in Adobe Illustrator.
plt.rcParams['svg.fonttype'] = 'none'

import os as _os

def _save_fig(basename):
    """Save SVG (editable text) and PNG (300 dpi).
    Detects Google Colab and saves to /content/ so files appear
    in the Colab file browser (left panel) for download.
    """
    try:
        import google.colab          # noqa: F401
        out_dir = '/content'
        _in_colab = True
    except ImportError:
        out_dir = _os.getcwd()
        _in_colab = False

    svg_out = _os.path.join(out_dir, basename + '.svg')
    png_out = _os.path.join(out_dir, basename + '.png')

    plt.savefig(svg_out, bbox_inches='tight')
    plt.savefig(png_out, bbox_inches='tight', dpi=300)

    print(f"Saved SVG: {svg_out}  (text editable in Illustrator)")
    print(f"Saved PNG: {png_out}  (300 dpi)")

    if _in_colab:
        print("Download: right-click the file in the Colab file browser,")
        print("  or run:  from google.colab import files")
        print(f" files.download('{svg_out}')")

from matplotlib.lines import Line2D

# ── STYLE ─────────────────────────────────────────────────────────
plt.rcParams.update({
    'svg.fonttype': 'none',   # keeps text editable in Illustrator
    'font.family':     'serif',
    'font.size':       10,
    'axes.linewidth':  0.8,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
})

C = {
    'Gas':     '#2ca02c',
    'Liquid':  '#1f77b4',
    'Surface': '#d62728',
    'Solid':   '#9467bd',
}

TIER_STYLE = {
    1:       ('o', True),
    '1r2a':  ('^', True),
    2:       ('s', True),
    '2diag': ('D', True),
    3:       ('o', False),
}

# ── η(χ) CURVE ────────────────────────────────────────────────────
chi_arr = np.logspace(-4, 2.3, 2000)
eta_arr = 2 * chi_arr / (1 + chi_arr ** 2)

# ── DATA ──────────────────────────────────────────────────────────
# (display_label, chi_mid, phase, tier, (x_text_factor, y_text_offset))
# chi_mid values verified in atlas_v1_verify_final.py.
systems = [
    ('CH₃NC',         0.0019,  'Gas',     2,      (-3.5, -0.05)),
    ('Cyclopropane',     0.0037,  'Gas',     2,      ( 1.7,  0.05)),
    ('NO₂',           0.0063,  'Gas',     1,      ( 1.6, -0.05)),
    ('CO/Cu(111)',       0.019,   'Surface', 1,      ( 1.8,  0.04)),
    ('Li⁺/LLZO',      0.118,   'Solid',   3,      ( 1.6,  0.04)),
    ('HPTS/H₂O',      1.44,    'Liquid',  '2diag',( 1.45,-0.07)),
    ('Fe(CN)₆/MeCN',  1.52,    'Liquid',  '1r2a', ( 1.35, 0.05)),
    ('t-BuCl/H₂O',  1.63,    'Liquid',  '1r2a', ( 1.35,-0.08)),
    ('N₂/K-Fe',       1.2825,  'Surface', 2,      ( 0.55, 0.06)),
]

# ── FIGURE ────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(7.0, 4.8))

# Regime shading
ax.axvspan(1e-4, 0.8, alpha=0.07, color='#2ca02c')
ax.axvspan(0.8,  1.3, alpha=0.20, color='#FFD700')
ax.axvspan(1.3, 200,  alpha=0.07, color='#d62728')
ax.axvline(0.8, color='#888800', lw=0.7, ls='--', alpha=0.7)
ax.axvline(1.3, color='#888800', lw=0.7, ls='--', alpha=0.7)
ax.axvline(1.0, color='gray',    lw=0.7, ls=':',  alpha=0.5)

# η(χ) curve
ax.semilogx(chi_arr, eta_arr, 'k-', lw=2.5, zorder=3,
            label='η(χ₀) = 2χ₀/(1+χ₀²)')

# Regime labels
for x, lbl, col in [
    (0.003, 'Underdamped',   '#1a6b1a'),
    (1.02,  'Near-critical', '#8B8000'),
    (12,    'Overdamped',    '#8B0000'),
]:
    ax.text(x, 1.07, lbl, fontsize=8.5, ha='center', color=col, style='italic')
ax.text(1.0, 1.02, 'χ₀ = 1', fontsize=8,
        ha='center', color='gray', style='italic', fontfamily='Cambria Math')

# Atlas systems
ms = 9
for label, chi_v, phase, tier, (dx, dy) in systems:
    eta_v = 2 * chi_v / (1 + chi_v ** 2)
    col   = C[phase]
    mk, filled = TIER_STYLE[tier]
    mfc = col  if filled else 'white'
    mew = 0.5  if filled else 1.5
    ax.plot(chi_v, eta_v, mk, ms=ms, color=col,
            mfc=mfc, mec=col, mew=mew, zorder=6)

    # Label placement
    if dx < 0:
        x_text = chi_v / abs(dx)
    else:
        x_text = chi_v * dx
    ax.text(x_text, eta_v + dy, label,
            fontsize=8, color='#333333', va='center', fontfamily='Cambria Math')

# Legend
legend_elements = [
    Line2D([0],[0], ls='-', color='k', lw=2.5,
           label='η(χ₀) = 2χ₀/(1+χ₀²)'),
    Line2D([0],[0], marker='o', color='#2ca02c', ms=ms,
           mfc='#2ca02c', ls='none', label='Gas'),
    Line2D([0],[0], marker='o', color='#d62728', ms=ms,
           mfc='#d62728', ls='none', label='Surface'),
    Line2D([0],[0], marker='o', color='#1f77b4', ms=ms,
           mfc='#1f77b4', ls='none', label='Liquid'),
    Line2D([0],[0], marker='o', color='#9467bd', ms=ms,
           mfc='white', mec='#9467bd', mew=1.5, ls='none',
           label='Solid (Tier 3)'),
]
ax.legend(handles=legend_elements, fontsize=8.5, loc='upper left',
          framealpha=0.9, edgecolor='#cccccc')

ax.set_xlabel(r'$\chi_0 = \Gamma_{\mathrm{eff}}\,/\,(2\Omega_0)$  (log scale)',
              fontsize=10.5)
ax.set_ylabel(r'Schematic dynamical efficiency projection  $\eta(\chi_0)$',
              fontsize=10.5)
ax.set_xlim(5e-5, 100)
ax.set_ylim(-0.04, 1.14)
ax.set_title('Approach-region dynamical efficiency landscape',
             fontsize=11.5, fontweight='bold')

plt.tight_layout(pad=0.9)

# ── SAVE ──────────────────────────────────────────────────────────
_save_fig('Atlas_Fig2_EtaCurve')
