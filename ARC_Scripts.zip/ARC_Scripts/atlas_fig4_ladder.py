"""
atlas_fig4_ladder.py
Cross-phase environmental friction ladder (Figure 4)

Synthesis figure: four phase lanes (Gas, Liquid, Surface, Solid) on a shared
log χ₀ axis. Each lane shows friction mechanism type, typical χ₀ range,
and individual systems. The five-order-of-magnitude gas→liquid→surface
progression is the main visual message.

Run in Google Colab:  !python atlas_fig4_ladder.py
Saves:  Atlas_Fig4_Ladder.svg  and  Atlas_Fig4_Ladder.png
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ── COLAB-AWARE SAVE WITH EDITABLE SVG TEXT ───────────────────────
# svg.fonttype = 'none' writes SVG <text> elements instead of path
# outlines. Labels open as editable text strings in Adobe Illustrator.
plt.rcParams['svg.fonttype'] = 'none'

import os as _os

def _save_fig(basename):
    """Save SVG (editable text) and PNG (300 dpi).
    Detects Google Colab and saves to /content/ so files appear
    in the Colab file browser (left panel) for download.
    """
    try:
        import google.colab          # noqa: F401
        out_dir = '/content'
        _in_colab = True
    except ImportError:
        out_dir = _os.getcwd()
        _in_colab = False

    svg_out = _os.path.join(out_dir, basename + '.svg')
    png_out = _os.path.join(out_dir, basename + '.png')

    plt.savefig(svg_out, bbox_inches='tight')
    plt.savefig(png_out, bbox_inches='tight', dpi=300)

    print(f"Saved SVG: {svg_out}  (text editable in Illustrator)")
    print(f"Saved PNG: {png_out}  (300 dpi)")

    if _in_colab:
        print("Download: right-click the file in the Colab file browser,")
        print("  or run:  from google.colab import files")
        print(f" files.download('{svg_out}')")


# ── STYLE ─────────────────────────────────────────────────────────
plt.rcParams.update({
    'svg.fonttype': 'none',   # keeps text editable in Illustrator
    'font.family':     'serif',
    'font.size':       10,
    'axes.linewidth':  0.8,
    'xtick.direction': 'in',
})

C = {
    'Gas':     '#2ca02c',
    'Liquid':  '#1f77b4',
    'Surface': '#d62728',
    'Solid':   '#9467bd',
}

# ── DATA ──────────────────────────────────────────────────────────
# χ₀ central values verified in atlas_v1_verify_final.py.
phases = [
    {
        'name':    'Gas',
        'label':   'Gas\nIVR / predissociation',
        'color':   C['Gas'],
        'range':   'χ₀ ~ 10⁻³–10⁻²',
        'desc':    'IVR friction only\nRepeated encounters required\n(RRKM excess energy)',
        'y':       3.5,
        'points':  [(0.0019, 'CH₃NC'), (0.0037, 'Cyclopropane'), (0.0063, 'NO₂')],
        'tier3':   False,
    },
    {
        'name':    'Liquid',
        'label':   'Liquid\nsolvent friction',
        'color':   C['Liquid'],
        'range':   'χ₀ ~ 1–10²',
        'desc':    'Solvent dielectric friction\nThermodynamic activation orthogonal',
        'y':       2.5,
        'points':  [(1.44,'HPTS'), (1.52,'Fe(CN)₆'), (1.63,'t-BuCl'), (80,'EtOH')],
        'tier3':   False,
    },
    {
        'name':    'Surface',
        'label':   'Surface\nelectronic friction',
        'color':   C['Surface'],
        'range':   'χ₀ ~ 10⁻²–1',
        'desc':    'Electronic hybridization\nK-promotion tunes χ₀',
        'y':       1.5,
        'points':  [(0.019,'CO/Cu'), (1.2825,'K-Fe')],
        'tier3':   False,
    },
    {
        'name':    'Solid',
        'label':   'Solid\nphonon friction',
        'color':   C['Solid'],
        'range':   'χ₀ ~ 0.12',
        'desc':    'Phonon friction (Tier 3)\nProspective prediction',
        'y':       0.5,
        'points':  [(0.118,'LLZO')],
        'tier3':   True,
    },
]

# ── FIGURE ────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(8.0, 4.0))

chi_min, chi_max = 3e-5, 3e2
ax.set_xscale('log')
ax.set_xlim(chi_min, chi_max)
ax.set_ylim(-0.1, 4.2)

# Regime shading
ax.axvspan(chi_min, 0.8, alpha=0.07, color='#2ca02c', zorder=0)
ax.axvspan(0.8,     1.3, alpha=0.18, color='#FFD700', zorder=0)
ax.axvspan(1.3, chi_max, alpha=0.07, color='#d62728', zorder=0)
ax.axvline(1.0, color='gray', lw=0.8, ls='--', alpha=0.5, zorder=1)

# Phase lane backgrounds and content
for ph in phases:
    y0 = ph['y']
    col = ph['color']

    # Lane background
    ax.axhspan(y0 - 0.45, y0 + 0.45, alpha=0.06, color=col)

    # Phase label (left)
    ax.text(4e-5, y0, ph['label'], fontsize=9, color=col,
            fontweight='bold', va='center', ha='left', linespacing=1.4)

    # Description (below label)
    ax.text(1.5e-4, y0 - 0.28, ph['desc'],
            fontsize=6.8, color='#555555', va='top', linespacing=1.35)

    # χ₀ range label (right)
    ax.text(5e1, y0, ph['range'],
            fontsize=8.5, color=col, va='center', ha='right', style='italic',
            fontfamily='Cambria Math')


    # Data points — stagger labels within each lane to prevent overlap
    # y_offsets cycles through above/below/above to separate close points
    y_offsets = [0.24, -0.26, 0.24, -0.26]
    for idx, (chi_v, label) in enumerate(ph['points']):
        tier3 = ph['tier3']
        mfc = 'white' if tier3 else col
        mew = 1.5     if tier3 else 0.5
        ax.plot(chi_v, y0, 'o', ms=9, color=col,
                mfc=mfc, mec=col, mew=mew, zorder=5)
        if len(label) <= 12:
            y_off = y_offsets[idx % len(y_offsets)]
            va = 'bottom' if y_off > 0 else 'top'
            ax.text(chi_v, y0 + y_off, label,
                    fontsize=7, ha='center', va=va,
                    color=col, fontfamily='Cambria Math')

# Separator lines between phases
for ys in [1.0, 2.0, 3.0]:
    ax.axhline(ys, color='#d0d0d0', lw=0.6, zorder=1)

# Upward arrow and label showing increasing coupling
ax.annotate('', xy=(3.5, 3.1), xytext=(3.5, 0.9),
            arrowprops=dict(arrowstyle='->', color='#888888', lw=1.2))
ax.text(5.5, 2.0, 'Increasing\nenvironmental\ncoupling',
        fontsize=7.5, ha='left', color='#666666',
        style='italic', linespacing=1.35)

# χ₀ = 1 label at bottom
ax.text(1.0, -0.08, 'χ₀ = 1\nexceptional point',
        fontsize=7.5, ha='center', color='gray',
        style='italic', va='top', linespacing=1.3, fontfamily='Cambria Math')

# Regime labels at top
for x, lbl, col in [
    (0.003, 'Underdamped',   '#1a6b1a'),
    (1.02,  'Near-critical', '#8B8000'),
    (15,    'Overdamped',    '#8B0000'),
]:
    ax.text(x, 4.1, lbl, fontsize=8.5, ha='center',
            color=col, style='italic')

# Bottom note on span
ax.text(0.99, 0.01,
        'Gas → Liquid → Surface: systematic χ₀ progression '
        'spanning ~5 orders of magnitude',
        transform=ax.transAxes, fontsize=8, ha='right', va='bottom',
        color='#333333', style='italic', fontfamily='Cambria Math')

ax.set_yticks([])
ax.set_xlabel(
    'Approach-region damping ratio  \u03c7\u2080 = \u0393\u1d07\u1da0\u1da0/(2\u03a9\u2080)  (log scale)',
    fontsize=10.5)
ax.spines['left'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
ax.set_title('Cross-phase environmental friction ladder',
             fontsize=11.5, fontweight='bold')

plt.tight_layout(pad=0.8)

# ── SAVE ──────────────────────────────────────────────────────────
_save_fig('Atlas_Fig4_Ladder')
