"""atlas_v1_liquids.py — Liquid-phase chi values for Atlas_Main_v1.tex"""
import math

HC = 1.23984193e-4; C = 2.99792458e10
EV2J = 1.602176634e-19; AMU2KG = 1.66053906660e-27
ANG2M = 1e-10; PS2S = 1e-12

def chi_b(tau_ps, lam, dq, m, ws):
    t=tau_ps*PS2S; l=lam*EV2J; d=dq*ANG2M; mk=m*AMU2KG
    w=ws*2*math.pi*C; w0=math.sqrt(2*l/(mk*d**2))
    return (w**2*t)/(2*w0)

def chi_a(dnu, nu): return dnu/(2*nu)
def eta(x): return 2*x/(1+x**2)

print("LIQUID-PHASE SYSTEMS")
print("-"*60)

# System 4: Fe(CN)6 ET
print("Fe(CN)6^3-/4- ET  (lambda=0.68eV, dQ=0.40A, m=150amu, Ws=100cm-1)")
for solv, tau in [("MeCN",0.20),("H2O",0.28),("MeOH",5.0),("EtOH",16.0),("DMSO",8.0)]:
    chi = chi_b(tau, 0.68, 0.40, 150, 100)
    print(f"  {solv:8s}: tau_L={tau:5.2f}ps  chi={chi:.4f}  eta={eta(chi):.4f}")

print()
print("t-BuCl SN1  (lambda=0.52eV, dQ=0.30A, m=120amu, Ws=100cm-1)")
for solv, tau in [("MeCN",0.20),("H2O",0.28),("HCOOH",0.70),("Acetone",0.50),("MeOH",5.0),("EtOH",16.0)]:
    chi = chi_b(tau, 0.52, 0.30, 120, 100)
    print(f"  {solv:8s}: tau_L={tau:5.2f}ps  chi={chi:.4f}")

print()
print("HPTS photoacid PT")
print(f"  Route A: nu=2750 cm-1, dnu_L=160 cm-1 -> chi={chi_a(160,2750):.4f}")
chi_h = chi_b(0.28, 0.25, 0.50, 1.008, 200)
chi_d = chi_b(0.44, 0.25, 0.50, 2.014, 200)
print(f"  Route B H2O (m=1.008amu): chi={chi_h:.4f}")
print(f"  Route B D2O (m=2.014amu): chi={chi_d:.4f}  D/H={chi_d/chi_h:.4f}")
print(f"  ARD proton-mass upper bound sqrt(2)*chi_H = {math.sqrt(2)*chi_h:.4f}")
print(f"  Route B D/H > sqrt(2): solvent tau_L isotope effect dominates.")
