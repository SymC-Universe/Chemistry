"""
atlas_fig1_crossphase.py
Cross-phase approach-region damping atlas (Figure 1)

All nine systems on one log-scale χ₀ axis, grouped by phase.
Marker SHAPE = evidence grade. Marker COLOR = phase.

Verified values from atlas_v1_verify_final.py (64 PASS, 0 FAIL).
Run in Google Colab:  !python atlas_fig1_crossphase.py
Saves:  Atlas_Fig1_CrossPhase.svg  and  Atlas_Fig1_CrossPhase.png
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ── COLAB-AWARE SAVE WITH EDITABLE SVG TEXT ───────────────────────
# svg.fonttype = 'none' writes SVG <text> elements instead of path
# outlines. Labels open as editable text strings in Adobe Illustrator.
plt.rcParams['svg.fonttype'] = 'none'

import os as _os

def _save_fig(basename):
    """Save SVG (editable text) and PNG (300 dpi).
    Detects Google Colab and saves to /content/ so files appear
    in the Colab file browser (left panel) for download.
    """
    try:
        import google.colab          # noqa: F401
        out_dir = '/content'
        _in_colab = True
    except ImportError:
        out_dir = _os.getcwd()
        _in_colab = False

    svg_out = _os.path.join(out_dir, basename + '.svg')
    png_out = _os.path.join(out_dir, basename + '.png')

    plt.savefig(svg_out, bbox_inches='tight')
    plt.savefig(png_out, bbox_inches='tight', dpi=300)

    print(f"Saved SVG: {svg_out}  (text editable in Illustrator)")
    print(f"Saved PNG: {png_out}  (300 dpi)")

    if _in_colab:
        print("Download: right-click the file in the Colab file browser,")
        print("  or run:  from google.colab import files")
        print(f" files.download('{svg_out}')")

from matplotlib.lines import Line2D

# ── STYLE ─────────────────────────────────────────────────────────
plt.rcParams.update({
    'svg.fonttype': 'none',   # keeps text editable in Illustrator
    'font.family':      'serif',
    'font.size':        10,
    'axes.linewidth':   0.8,
    'xtick.direction':  'in',
    'ytick.direction':  'in',
    'xtick.major.size': 4,
    'ytick.major.size': 4,
})

# ── COLOR SCHEME (phase) ──────────────────────────────────────────
C = {
    'Gas':     '#2ca02c',
    'Liquid':  '#1f77b4',
    'Surface': '#d62728',
    'Solid':   '#9467bd',
}

# ── MARKER SCHEME (evidence grade) ───────────────────────────────
#  Tier 1       = filled circle      (direct measurement)
#  Tier 1r/2a   = filled triangle    (relative direct / absolute bracketed)
#  Tier 2       = filled square      (computed / bracketed)
#  Tier 2/diag  = filled diamond     (abs. Tier 2; Route A diagnostic)
#  Tier 3       = open circle        (prospective)
TIER_STYLE = {
    1:       ('o', True),
    '1r2a':  ('^', True),
    2:       ('s', True),
    '2diag': ('D', True),
    3:       ('o', False),
}

# ── DATA ──────────────────────────────────────────────────────────
# Labels use Unicode subscripts/superscripts (NO dollar signs).
# Any string containing $...$ is rendered by matplotlib's mathtext
# engine as outlined paths even with svg.fonttype='none'. Plain
# Unicode strings become single editable <text> elements in Illustrator.
# Unicode used: ₂ ₃ ₆ ⁺
systems = [
    ('CH\u2083NC',           0.0008, 0.0019, 0.0054, 'Gas',     2),
    ('Cyclopropane',         0.0014, 0.0037, 0.0070, 'Gas',     2),
    ('NO\u2082',             0.0018, 0.0063, 0.0133, 'Gas',     1),
    ('CO/Cu(111)',           0.015,  0.019,  0.026,  'Surface', 1),
    ('N\u2082/K-Fe(111)',    0.95,   1.2825, 1.55,   'Surface', 2),
    ('HPTS/H\u2082O',        0.5,    1.44,   3.5,    'Liquid',  '2diag'),
    ('Fe(CN)\u2086/MeCN',    0.22,   1.52,   5.0,    'Liquid',  '1r2a'),
    ('t-BuCl/H\u2082O',      0.25,   1.63,   5.5,    'Liquid',  '1r2a'),
    ('Li\u207A/LLZO',        0.071,  0.118,  0.200,  'Solid',   3),
]

# y-positions (arbitrary units, groups by phase)
Y = {
    'CH\u2083NC':          8.4,
    'Cyclopropane':        7.5,
    'NO\u2082':            6.6,
    'CO/Cu(111)':          5.1,
    'N\u2082/K-Fe(111)':   4.2,
    'Fe(CN)\u2086/MeCN':   2.8,
    't-BuCl/H\u2082O':     1.9,
    'HPTS/H\u2082O':       1.0,
    'Li\u207A/LLZO':      -0.5,
}

# ── FIGURE ────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(7.5, 5.4))

# Regime shading
ax.axvspan(1e-5,  0.8, alpha=0.07, color='#2ca02c', zorder=0)
ax.axvspan(0.8,   1.3, alpha=0.18, color='#FFD700', zorder=0)
ax.axvspan(1.3,  2e2,  alpha=0.07, color='#d62728', zorder=0)

# Regime labels
for x, lbl, col in [
    (0.003, 'Underdamped',   '#1a6b1a'),
    (1.02,  'Near-critical', '#8B8000'),
    (15,    'Overdamped',    '#8B0000'),
]:
    ax.text(x, 9.15, lbl, fontsize=8.5, color=col,
            ha='center', style='italic')

# Phase group labels (left margin)
for y, lbl, col in [
    (7.5,  'Gas',             '#2ca02c'),
    (4.65, 'Surface',         '#d62728'),
    (1.9,  'Liquid',          '#1f77b4'),
    (-0.5, 'Solid\n(Tier 3)', '#9467bd'),
]:
    ax.text(5e-6, y, lbl, fontsize=9, color=col,
            fontweight='bold', va='center', ha='left')

# Phase separator lines
for ys in [3.5, 5.7, 0.0]:
    ax.axhline(ys, color='#d0d0d0', lw=0.6, zorder=1)

# χ₀ = 1 reference line
ax.axvline(1.0, color='gray', lw=0.8, ls='--', alpha=0.6, zorder=2)
ax.text(1.0, -0.9, '\u03c7\u2080 = 1', fontsize=8,
        ha='center', color='gray', style='italic')

ms = 10
for label, lo, mid, hi, phase, tier in systems:
    y   = Y[label]
    col = C[phase]
    mk, filled = TIER_STYLE[tier]

    # Uncertainty bracket
    ax.plot([lo, hi], [y, y], '-', color=col, lw=1.2, alpha=0.5, zorder=2)
    for xb in [lo, hi]:
        ax.plot([xb, xb], [y - 0.15, y + 0.15], '-',
                color=col, lw=1.0, alpha=0.5)

    # Central marker
    mfc = col  if filled else 'white'
    mew = 0.5  if filled else 1.5
    ax.plot(mid, y, mk, ms=ms, color=col,
            mfc=mfc, mec=col, mew=mew, zorder=5)

    # System label
    x_text = mid * 1.9 if mid < 0.1 else mid * 1.6
    ax.text(x_text, y, label, fontsize=9,
            va='center', color='#333333')

# Legend
legend_elements = [
    Line2D([0],[0], marker='o', color='#777777', ms=ms, mfc='#777777',
           mec='#777777', ls='none', label='Tier 1  direct measurement'),
    Line2D([0],[0], marker='^', color='#777777', ms=ms, mfc='#777777',
           mec='#777777', ls='none', label='Tier 1r/2a  relative direct / absolute bracketed'),
    Line2D([0],[0], marker='s', color='#777777', ms=ms, mfc='#777777',
           mec='#777777', ls='none', label='Tier 2  computed / bracketed'),
    Line2D([0],[0], marker='D', color='#777777', ms=ms, mfc='#777777',
           mec='#777777', ls='none', label='Tier 2/diag  abs. Tier 2; Route A diagnostic'),
    Line2D([0],[0], marker='o', color='#9467bd', ms=ms, mfc='white',
           mec='#9467bd', mew=1.5, ls='none', label='Tier 3  prospective'),
]
# Legend placed in the empty left portion of the Liquid section row.
# Liquid systems sit at chi_0 ~ 1.4-1.6 (right side); the far-left
# of that row is clear of all data points and labels.
# bbox_to_anchor in axes coords: x=0.01 (far left), y=0.27 (liquid band).
ax.legend(handles=legend_elements,
          loc='center left',
          bbox_to_anchor=(0.01, 0.27),
          fontsize=8,
          framealpha=0.92,
          edgecolor='#cccccc',
          title='Evidence grade (marker shape)',
          title_fontsize=8.5)

ax.set_xscale('log')
ax.set_xlim(4e-6, 3e2)
ax.set_ylim(-1.6, 9.6)
ax.set_yticks([])
ax.set_xlabel(
    r'Approach-region damping ratio  $\chi_0 = \Gamma_{\mathrm{eff}}\,/\,(2\Omega_0)$',
    fontsize=10.5)
ax.spines['left'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
ax.set_title('Cross-phase approach-region damping atlas',
             fontsize=11.5, fontweight='bold', pad=10)

plt.tight_layout(pad=0.9)

# ── SAVE ──────────────────────────────────────────────────────────
_save_fig('Atlas_Fig1_CrossPhase')
