"""atlas_v1_solids.py — Solid-state chi values for Atlas_Main_v1.tex"""
import math
HC = 1.23984193e-4

def chi_c(g, nu): return g / (2*HC*nu)
def chi_a(dnu, nu): return dnu / (2*nu)
def eta(x): return 2*x/(1+x**2)

print("SOLID-STATE SYSTEMS")
print("-"*55)

# System 1: N2/K-Fe(111)
chi = chi_c(0.45, 1415)
print(f"N2/K-Fe(111): chi={chi:.4f}  eta={eta(chi):.4f}  Tier 2 Route C")
print(f"  Fe(111) bare: chi={chi_c(0.05,2100):.4f}  Fe(110): chi={chi_c(0.30,2000):.4f}")

# System 2: CO/Cu(111)
print(f"CO/Cu(111):   chi={chi_a(13,344):.4f} ({chi_a(10,344):.4f}--{chi_a(18,344):.4f})  Tier 1 Route A")

# System 3: Li/LLZO
print(f"Li+/LLZO:     chi={chi_a(55,234):.4f} ({chi_a(40,280):.4f}--{chi_a(80,200):.4f})  Tier 2-3 Route C-ph")
print()
print("Note: Li/LLZO is Tier 3 pending direct THz linewidth measurement of Gamma_ph.")
