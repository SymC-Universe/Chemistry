"""
atlas_fig3_routes.py
Estimator route data: Route B solvent series + Route C surface progression (Figure 3)

Panel (a): Fe(CN)₆³⁻/⁴⁻ and t-BuCl χ₀ across six solvents each.
           Shows Route B data in full; relative ordering is Tier 1.
Panel (b): N₂/Fe(111) series showing K-promotion tuning χ₀ into window.
           Route C, Tier 2.

Run in Google Colab:  !python atlas_fig3_routes.py
Saves:  Atlas_Fig3_Routes.svg  and  Atlas_Fig3_Routes.png
"""

import math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ── COLAB-AWARE SAVE WITH EDITABLE SVG TEXT ───────────────────────
# svg.fonttype = 'none' writes SVG <text> elements instead of path
# outlines. Labels open as editable text strings in Adobe Illustrator.
plt.rcParams['svg.fonttype'] = 'none'

import os as _os

def _save_fig(basename):
    """Save SVG (editable text) and PNG (300 dpi).
    Detects Google Colab and saves to /content/ so files appear
    in the Colab file browser (left panel) for download.
    """
    try:
        import google.colab          # noqa: F401
        out_dir = '/content'
        _in_colab = True
    except ImportError:
        out_dir = _os.getcwd()
        _in_colab = False

    svg_out = _os.path.join(out_dir, basename + '.svg')
    png_out = _os.path.join(out_dir, basename + '.png')

    plt.savefig(svg_out, bbox_inches='tight')
    plt.savefig(png_out, bbox_inches='tight', dpi=300)

    print(f"Saved SVG: {svg_out}  (text editable in Illustrator)")
    print(f"Saved PNG: {png_out}  (300 dpi)")

    if _in_colab:
        print("Download: right-click the file in the Colab file browser,")
        print("  or run:  from google.colab import files")
        print(f" files.download('{svg_out}')")


# ── STYLE ─────────────────────────────────────────────────────────
plt.rcParams.update({
    'svg.fonttype': 'none',   # keeps text editable in Illustrator
    'font.family':     'serif',
    'font.size':       10,
    'axes.linewidth':  0.8,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
})

# ── CONSTANTS ─────────────────────────────────────────────────────
HC_EV_CM  = 1.23984193e-4
C_CM_S    = 2.99792458e10
EV_TO_J   = 1.602176634e-19
AMU_TO_KG = 1.66053906660e-27
ANG_TO_M  = 1e-10
PS_TO_S   = 1e-12

def chi_route_b(tau_ps, lam_ev, dq_ang, m_amu, omega_s_cm1):
    """Route B absolute χ₀ (Tier 2).
    Relative ordering across a fixed DA pair / solvent series is Tier 1."""
    tau = tau_ps   * PS_TO_S
    lam = lam_ev   * EV_TO_J
    dq  = dq_ang   * ANG_TO_M
    m   = m_amu    * AMU_TO_KG
    ws  = omega_s_cm1 * 2 * math.pi * C_CM_S
    w0  = math.sqrt(2 * lam / (m * dq ** 2))
    return (ws ** 2 * tau) / (2 * w0)

def chi_route_c(gamma_ev, nu_cm1):
    """Route C electronic friction χ₀."""
    return gamma_ev / (2 * HC_EV_CM * nu_cm1)

# ── DATA: ROUTE B SOLVENT SERIES ──────────────────────────────────
# τ_L from Jimenez et al. (1994) / Weaver (1990) compilation.
# λ and ΔQ from Grampp & Jaenicke (1990) for Fe(CN)₆.

solvents_fe  = ['MeCN', 'H₂O', 'MeOH', 'DMSO', 'DMF',  'EtOH']
tau_fe       = [0.20,   0.28,  5.0,    8.0,    9.0,    16.0]   # ps

solvents_sn1 = ['MeCN', 'H₂O', 'HCOOH','Acetone','MeOH', 'EtOH']
tau_sn1      = [0.20,   0.28,  0.70,   0.50,    5.0,    16.0]  # ps

# Route B parameters  (m_eff = central estimate, absolute values are Tier 2)
LAM_FE  = 0.68;  DQ_FE  = 0.40;  M_FE  = 150.0;  WS = 100.0
LAM_SN1 = 0.52;  DQ_SN1 = 0.30;  M_SN1 = 120.0

chi_fe  = [chi_route_b(t, LAM_FE,  DQ_FE,  M_FE,  WS) for t in tau_fe]
chi_sn1 = [chi_route_b(t, LAM_SN1, DQ_SN1, M_SN1, WS) for t in tau_sn1]

# ── DATA: ROUTE C K-Fe SERIES ─────────────────────────────────────
# Γ_NN and ν̃ from ARD companion paper (Christensen 2026 ChemRxiv).
# Methodology: Maurer et al. PRB 2016.
surfaces   = ['Fe(111)\nunpromoted', 'Fe(110)', 'K-Fe(111)\nK-promoted']
chi_surf   = [
    chi_route_c(0.05, 2100),   # unpromoted Fe(111)
    chi_route_c(0.30, 2000),   # Fe(110)
    chi_route_c(0.45, 1415),   # K-promoted Fe(111)  → χ = 1.2825
]

# ── FIGURE ────────────────────────────────────────────────────────
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9.0, 4.2),
                                gridspec_kw={'width_ratios': [1.5, 1]})

# ── PANEL A: Route B solvent series ──────────────────────────────
n_fe  = len(solvents_fe)
n_sn1 = len(solvents_sn1)
x_fe  = np.arange(n_fe)
x_sn1 = np.arange(n_sn1) + n_fe + 0.8

# Regime shading
ax1.axhspan(0.8, 1.3, alpha=0.18, color='#FFD700', zorder=0)
ax1.axhline(1.0, color='gray', lw=0.7, ls=':', alpha=0.5)
ax1.axhspan(0.0, 0.8,   alpha=0.06, color='#2ca02c')
ax1.axhspan(1.3, 1000,  alpha=0.06, color='#d62728')

# Bars
ax1.bar(x_fe,  chi_fe,  0.72, color='#1f77b4', alpha=0.85,
        label='Fe(CN)₆³⁻/⁴⁻ (Route B, Tier 1r/2a)', zorder=3,
        ec='white', lw=0.4)
ax1.bar(x_sn1, chi_sn1, 0.72, color='#ff7f0e', alpha=0.85,
        label='t-BuCl SN1 (Route B, Tier 1r/2a)', zorder=3,
        ec='white', lw=0.4)

# Solvent labels on x-axis
all_solvents = solvents_fe + [''] + solvents_sn1
all_x        = list(x_fe) + [n_fe + 0.4] + list(x_sn1)
ax1.set_xticks(all_x)
ax1.set_xticklabels(
    solvents_fe + [''] + solvents_sn1,
    fontsize=8, rotation=45, ha='right'
)

# Value annotations above bars
for x, v in zip(list(x_fe) + list(x_sn1),
                list(chi_fe) + list(chi_sn1)):
    if v < 15:
        ax1.text(x, v + 0.3, f'{v:.1f}', ha='center', va='bottom',
                 fontsize=6.5, color='#333333')

ax1.set_yscale('log')
ax1.set_ylim(0.05, 500)
ax1.set_xlim(-0.6, n_fe + n_sn1 + 1.0)
ax1.set_ylabel(r'$\chi_0$ (absolute, central estimate)', fontsize=10)
ax1.axvline(n_fe + 0.4, color='#cccccc', lw=0.8, ls='--')
ax1.legend(fontsize=8, loc='upper left', framealpha=0.9)

ax1.text(2.3, 1.05, 'Near-critical', fontsize=7.5,
         color='#8B8000', style='italic', ha='center')
ax1.text(0.5, 0.07, 'Underdamped', fontsize=7.5,
         color='#1a6b1a', style='italic', ha='center',
         transform=ax1.transAxes)
ax1.text(0.01, 0.96,
         'Tier 1: relative solvent ordering\nTier 2: absolute placement',
         transform=ax1.transAxes, fontsize=7.5, va='top',
         style='italic', color='#555555')
ax1.set_title('(a)  Route B: solvent series', fontsize=10, fontweight='bold')

# ── PANEL B: Route C K-Fe surface progression ────────────────────
colors_surf = ['#ccaaaa', '#dd6666', '#d62728']

ax2.axhspan(0.8, 1.3, alpha=0.18, color='#FFD700', zorder=0)
ax2.axhline(1.0, color='gray', lw=0.7, ls=':', alpha=0.5)
ax2.axhspan(0.0, 0.8, alpha=0.06, color='#2ca02c')

for i, (surf, chi_v, col) in enumerate(zip(surfaces, chi_surf, colors_surf)):
    ax2.bar(i, chi_v, 0.55, color=col, alpha=0.90,
            ec='white', lw=0.5, zorder=3)
    ax2.text(i, chi_v + 0.02, f'χ₀ = {chi_v:.3f}',
             ha='center', va='bottom', fontsize=8, color='#333333', fontfamily='Cambria Math')

# Arrow showing progression into window
ax2.annotate('', xy=(1.95, 1.10), xytext=(0.05, 0.28),
             arrowprops=dict(arrowstyle='->', color='#d62728',
                             lw=1.4, connectionstyle='arc3,rad=-0.2'))
ax2.text(0.95, 0.58, 'K-promotion\ntunes χ₀\ninto window',
         fontsize=8, ha='center', color='#d62728', style='italic', fontfamily='Cambria Math')

ax2.set_xlim(-0.5, 2.5)
ax2.set_ylim(0, 1.60)
ax2.set_xticks([0, 1, 2])
ax2.set_xticklabels(surfaces, fontsize=8.5)
ax2.set_ylabel(r'$\chi_0$ (Route C, Tier 2)', fontsize=10)
ax2.text(0.72, 1.07, 'Near-critical', fontsize=7.5,
         color='#8B8000', style='italic', ha='center')
ax2.text(0.02, 0.97, 'Route C | Tier 2',
         transform=ax2.transAxes, fontsize=8, va='top',
         style='italic', color='#555555')
ax2.set_title('(b)  Route C: K-Fe surface series',
              fontsize=10, fontweight='bold')

plt.tight_layout(pad=0.9)

# ── SAVE ──────────────────────────────────────────────────────────
_save_fig('Atlas_Fig3_Routes')
