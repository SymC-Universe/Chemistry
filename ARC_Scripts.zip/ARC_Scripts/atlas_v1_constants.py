"""
atlas_v1_constants.py
Canonical constants and shared functions for the atlas calculation package

Import this module in any script that needs to compute chi_0:
  from atlas_v1_constants import chi_a, chi_b, chi_c, ivr_cm1, eta, HC_EV_CM

All constants verified in atlas_v1_verify_final.py (64 PASS, 0 FAIL).
No literature values here — only SI constants and derived functions.

Run in Google Colab:  !python atlas_v1_constants.py
  (runs a self-test and prints all constants and verifications)
"""

import math

# ── PHYSICAL CONSTANTS (SI 2019 exact values where applicable) ────
HC_EV_CM  = 1.23984193e-4    # eV·cm = h*c in spectroscopy units
C_CM_S    = 2.99792458e10    # cm/s  = speed of light
EV_TO_J   = 1.602176634e-19  # J/eV  (elementary charge, exact SI 2019)
AMU_TO_KG = 1.66053906660e-27 # kg/amu
ANG_TO_M  = 1e-10            # m/Å
PS_TO_S   = 1e-12            # s/ps

# ── ROUTE A ───────────────────────────────────────────────────────
def chi_a(dnu_L, nu):
    """Route A spectroscopic estimator.

    chi_spec = Delta_nu_L / (2 * nu_bar)

    Args:
        dnu_L : Lorentzian FWHM of the approach mode (cm^-1)
        nu    : Mode frequency (cm^-1)

    Returns:
        chi_0 (dimensionless)

    Validity: Lorentzian fraction of the observed lineshape must exceed 50%.
    Gas-phase: dnu_L is the IVR linewidth Gamma_IVR or predissociation
    width Gamma_pd, not a bath friction coefficient.
    """
    return dnu_L / (2.0 * nu)

# ── ROUTE B ───────────────────────────────────────────────────────
def chi_b(tau_ps, lam_ev, dq_ang, m_amu, omega_s_cm1):
    """Route B solvent relaxation estimator.

    chi_0 = (Omega_s^2 * tau_L) / (2 * Omega_0)
    where Omega_0 = sqrt(2 * lambda / (m_eff * DeltaQ^2))

    Args:
        tau_ps       : Longitudinal relaxation time (ps)
        lam_ev       : Marcus reorganization energy (eV)
        dq_ang       : Coordinate displacement (Angstrom)
        m_amu        : Effective mass (amu)
        omega_s_cm1  : Debye-Drude bath frequency (cm^-1)

    Returns:
        chi_0 (dimensionless)

    Tier: absolute value is Tier 2 (m_eff, Omega_s uncertainty ~1 order of
    magnitude). Relative ordering for fixed DA pair is Tier 1 (tau_L ratio
    cancels m_eff, Omega_s dependence when parameters are held constant).

    Scaling law: chi_0 proportional to Omega_s^2 * sqrt(m_eff)
    """
    tau = tau_ps      * PS_TO_S
    lam = lam_ev      * EV_TO_J
    dq  = dq_ang      * ANG_TO_M
    m   = m_amu       * AMU_TO_KG
    ws  = omega_s_cm1 * 2 * math.pi * C_CM_S
    w0  = math.sqrt(2 * lam / (m * dq ** 2))
    return (ws ** 2 * tau) / (2 * w0)

# ── ROUTE C ───────────────────────────────────────────────────────
def chi_c(gamma_ev, nu_cm1):
    """Route C DFT electronic friction estimator.

    chi_DFT = Gamma_NN / (2 * hc * nu_bar)

    Args:
        gamma_ev : Newns-Anderson hybridization energy width (eV)
                   Gamma_NN = 2*pi*|V_k|^2 * rho(E_F)
                   This is an ELECTRONIC energy width, not a
                   vibrational friction coefficient.
        nu_cm1   : Approach mode frequency (cm^-1)

    Returns:
        chi_0 (dimensionless)

    Notes:
        - This gives a lower bound when phononic friction also contributes.
        - The Fano asymmetry parameter q and Gamma_NN are independent
          quantities; Fano profiles indicate electronic coupling but
          do not establish that electronic friction dominates.
    """
    return gamma_ev / (2.0 * HC_EV_CM * nu_cm1)

# ── IVR CONVERSION ────────────────────────────────────────────────
def ivr_cm1(tau_s):
    """Convert IVR lifetime or predissociation lifetime to linewidth.

    Gamma (cm^-1) = 1 / (2 * pi * c * tau)

    Args:
        tau_s : IVR lifetime or predissociation lifetime (seconds)

    Returns:
        Gamma_IVR (cm^-1)

    Derivation: from energy-time uncertainty Gamma = hbar/tau.
    Converting Gamma from energy to wavenumbers:
        Gamma (cm^-1) = Gamma (J) / (h*c) = (hbar/tau) / (h*c)
                      = 1 / (2*pi*c*tau)
    """
    return 1.0 / (2 * math.pi * C_CM_S * tau_s)

# ── ETA FUNCTION ──────────────────────────────────────────────────
def eta(chi):
    """Reduced dynamical efficiency of the approach coordinate.

    eta(chi) = 2*chi / (1 + chi^2)

    This is the commitment probability per encounter in the classical
    damped-oscillator approximation. Maximum eta=1 at chi=1 (exceptional
    point). For chi << 1: eta ~ 2*chi (small-chi approximation).
    For chi >> 1: eta ~ 2/chi (overdamped limit).

    For gas-phase systems (chi ~ 10^-3), eta ~ 2*chi gives the
    per-encounter commitment probability as a STRUCTURAL ANALOGY,
    not a rigorous quantum-mechanical prediction.
    """
    return 2 * chi / (1 + chi ** 2)

# ── REGIME CLASSIFICATION ─────────────────────────────────────────
def regime(chi):
    """Classify chi_0 into dynamical regime.

    Returns: 'underdamped', 'near-critical', or 'overdamped'
    Operational window: [0.8, 1.3] (eta >= 0.95 throughout)
    """
    if chi < 0.8:   return "underdamped"
    elif chi <= 1.3: return "near-critical"
    else:           return "overdamped"

# ── SELF-TEST ─────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys

    PASS = 0; FAIL = 0

    def check(label, got, exp, tol=1e-4):
        global PASS, FAIL
        if exp == 0:
            ok = abs(got) < tol
        else:
            ok = abs(got - exp) / abs(exp) < tol
        sym = "PASS" if ok else "FAIL"
        if ok: PASS += 1
        else:  FAIL += 1
        print(f"  [{sym}] {label}")
        if not ok:
            print(f"         got={got:.8g}  exp={exp:.8g}")

    print("atlas_v1_constants.py self-test")
    print("=" * 50)
    print()
    print("Constants:")
    print(f"  HC_EV_CM  = {HC_EV_CM:.8e} eV·cm")
    print(f"  C_CM_S    = {C_CM_S:.8e} cm/s")
    print(f"  EV_TO_J   = {EV_TO_J:.8e} J/eV")
    print()

    # HC_EV_CM derivation cross-check
    HC_computed = (6.62607015e-34 * 2.99792458e8 * 100) / 1.602176634e-19
    check("HC_EV_CM matches h*c/e", HC_computed, HC_EV_CM, tol=1e-7)

    # Route A
    check("chi_a: CO/Cu = 0.01889",    chi_a(13.0, 344.0), 0.018895, tol=1e-4)
    check("chi_a: NO2 = 0.00625",      chi_a(10.0, 800.0), 0.006250, tol=1e-4)
    check("chi_a: CH3NC = 0.001923",   chi_a(ivr_cm1(3e-12), 460.0), 0.001923, tol=1e-3)

    # Route C
    check("chi_c: K-Fe = 1.2825",      chi_c(0.45, 1415), 1.2825, tol=1e-4)
    check("chi_c: bare Fe = 0.0960",   chi_c(0.05, 2100), 0.0960, tol=1e-3)

    # IVR conversion
    check("ivr_cm1: 3ps -> 1.770",     ivr_cm1(3e-12), 1.770, tol=1e-3)

    # eta
    check("eta(1.0) = 1.0",            eta(1.0), 1.0)
    check("eta(0.8) >= 0.95",          eta(0.8), 0.975610, tol=1e-4)
    check("eta(1.3) >= 0.95",          eta(1.3), 0.966543, tol=1e-4)
    check("eta ~ 2*chi at chi=0.001",  eta(0.001), 0.002, tol=1e-3)

    # Route B scaling: chi proportional to Omega_s^2 * sqrt(m_eff)
    c1 = chi_b(0.20, 0.68, 0.40, 150, 100)
    c2 = chi_b(0.20, 0.68, 0.40, 300, 100)
    c3 = chi_b(0.20, 0.68, 0.40, 150, 150)
    check("chi_b: central = 1.5174",   c1, 1.5174, tol=1e-3)
    check("chi_b scales as sqrt(m)",   c2/c1, math.sqrt(2), tol=1e-5)
    check("chi_b scales as Omega_s^2", c3/c1, (150/100)**2, tol=1e-5)

    # HPTS D/H bracket independence
    chi_H = chi_b(0.28, 0.25, 0.50, 1.008, 200)
    chi_D = chi_b(0.44, 0.25, 0.50, 2.014, 200)
    ratio_actual   = chi_D / chi_H
    ratio_formula  = (0.44/0.28) * math.sqrt(2.014/1.008)
    check("HPTS D/H ratio = tau_D/tau_H * sqrt(m_D/m_H)",
          ratio_actual, ratio_formula, tol=1e-6)

    print()
    print(f"  PASS: {PASS}  FAIL: {FAIL}")
    print(f"  {'ALL PASS ✓' if FAIL == 0 else 'FAILURES — review before use'}")
    if FAIL > 0:
        sys.exit(1)
