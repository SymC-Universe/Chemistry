"""atlas_v1_gases.py — Gas-phase chi values for Atlas_Main_v1.tex"""
import math
C = 2.99792458e10
def chi_a(dnu, nu): return dnu/(2*nu)
def ivr(tau_s): return 1/(2*math.pi*C*tau_s)
def eta(x): return 2*x/(1+x**2)

print("GAS-PHASE SYSTEMS (IVR / predissociation linewidths)")
print("Note: Gamma arises from IVR or predissociation, not bath friction.")
print("-"*60)

# Cyclopropane
lo,mid,hi = chi_a(3,1070),chi_a(8,1070),chi_a(15,1070)
print(f"Cyclopropane->propene: chi={lo:.5f}--{hi:.5f}  central={mid:.5f}")
print(f"  N_encounters(central) = {1/eta(mid):.0f}")

# NO2
lo2,mid2,hi2 = chi_a(3,850),chi_a(10,800),chi_a(20,750)
print(f"NO2->NO+O predissoc.:  chi={lo2:.5f}--{hi2:.5f}  central={mid2:.5f}")
print(f"  N_encounters(central) = {1/eta(mid2):.0f}")

# CH3NC
g = ivr(3e-12)
lo3,mid3,hi3 = chi_a(1.5,510),chi_a(g,460),chi_a(5.0,400)
print(f"CH3NC->CH3CN:          chi={lo3:.5f}--{hi3:.5f}  central={mid3:.5f}")
print(f"  IVR: tau=3ps -> Gamma={g:.3f} cm-1")
print(f"  N_encounters(central) = {1/eta(mid3):.0f}")
