"""
atlas_figS3_gasphase.py
Gas-phase systems: low-χ₀ underdamped limit (Supplementary Figure S3)

Log-log plot of P_commit = η(χ₀) vs χ₀ in the deeply underdamped regime.
Shows that the small-χ approximation P_commit ≈ 2χ₀ is exact at χ < 0.01.
All three gas-phase systems are placed on this curve with:
  - central χ₀ values
  - corresponding N_encounters ≈ 1/(2χ₀)

IMPORTANT: the P_commit values and N_encounters are classical structural-analogy
estimates, not quantum-mechanical predictions (stated explicitly in manuscript
and in the figure annotation).

Verified values from atlas_v1_verify_final.py:
  CH₃NC:       χ₀ = 0.0019, N_enc ≈ 262
  Cyclopropane: χ₀ = 0.0037, N_enc ≈ 134
  NO₂:          χ₀ = 0.0063, N_enc ≈  80

Run in Google Colab:  !python atlas_figS3_gasphase.py
Saves:  Atlas_FigS3_GasPhase.svg  and  Atlas_FigS3_GasPhase.png
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ── COLAB-AWARE SAVE WITH EDITABLE SVG TEXT ───────────────────────
# svg.fonttype = 'none' writes SVG <text> elements instead of path
# outlines. Labels open as editable text strings in Adobe Illustrator.
plt.rcParams['svg.fonttype'] = 'none'

import os as _os

def _save_fig(basename):
    """Save SVG (editable text) and PNG (300 dpi).
    Detects Google Colab and saves to /content/ so files appear
    in the Colab file browser (left panel) for download.
    """
    try:
        import google.colab          # noqa: F401
        out_dir = '/content'
        _in_colab = True
    except ImportError:
        out_dir = _os.getcwd()
        _in_colab = False

    svg_out = _os.path.join(out_dir, basename + '.svg')
    png_out = _os.path.join(out_dir, basename + '.png')

    plt.savefig(svg_out, bbox_inches='tight')
    plt.savefig(png_out, bbox_inches='tight', dpi=300)

    print(f"Saved SVG: {svg_out}  (text editable in Illustrator)")
    print(f"Saved PNG: {png_out}  (300 dpi)")

    if _in_colab:
        print("Download: right-click the file in the Colab file browser,")
        print("  or run:  from google.colab import files")
        print(f" files.download('{svg_out}')")

from matplotlib.lines import Line2D

# ── STYLE ─────────────────────────────────────────────────────────
plt.rcParams.update({
    'svg.fonttype': 'none',   # keeps text editable in Illustrator
    'font.family':     'serif',
    'font.size':       10,
    'axes.linewidth':  0.8,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
})

# ── FUNCTIONS ─────────────────────────────────────────────────────
def eta(chi):
    return 2 * chi / (1 + chi ** 2)

def n_enc(chi):
    return 1.0 / eta(chi)

# ── DATA ──────────────────────────────────────────────────────────
# χ₀ central values verified in atlas_v1_verify_final.py.
gas_systems = [
    ('CH₃NC',     0.0019, '#2ca02c'),
    ('Cyclopropane', 0.0037, '#ff7f0e'),
    ('NO₂',       0.0063, '#1f77b4'),
]

# ── FIGURE ────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(5.8, 4.4))

chi_range = np.logspace(-4, -0.5, 2000)

ax.loglog(chi_range, eta(chi_range), 'k-', lw=2.2, zorder=4,
          label='η(χ₀) = 2χ₀/(1+χ₀²)')
ax.loglog(chi_range, 2 * chi_range,  'k--', lw=1.2, alpha=0.5, zorder=3,
          label='Pcommit ≈ 2χ₀  (small-χ)')

# System points and N_encounters annotations
ms = 10
for label, chi_v, col in gas_systems:
    eta_v = eta(chi_v)
    N     = n_enc(chi_v)
    ax.plot(chi_v, eta_v, 'o', ms=ms, color=col,
            mfc=col, mec='white', mew=0.5, zorder=6)
    ax.text(chi_v * 1.45, eta_v * 1.25,
            f'{label}\nNenc ≈ {N:.0f}',
            fontsize=8.5, color=col, va='bottom', linespacing=1.4, fontfamily='Cambria Math')

ax.legend(fontsize=9, loc='upper left', framealpha=0.9,
          prop={'family': 'Cambria Math'})

ax.set_xlabel(r'$\chi_0$  (log scale)', fontsize=10.5)
ax.set_ylabel(
    'Per-encounter commitment  Pcommit  (log scale)',
    fontsize=10.5)
ax.set_xlim(1e-4, 0.35)
ax.set_ylim(1e-4, 0.12)

ax.set_title(r'Gas-phase systems: low-$\chi_0$ underdamped limit',
             fontsize=11, fontweight='bold')

ax.text(0.02, 0.04,
        'RRKM excess-energy requirement as low per-encounter commitment.\n'
        'Structural-analogy estimate; not a quantum-mechanical prediction.',
        fontfamily='Cambria Math',
        transform=ax.transAxes, fontsize=8.5, va='bottom',
        color='#555555', style='italic', linespacing=1.45)

plt.tight_layout(pad=0.9)

# ── SAVE ──────────────────────────────────────────────────────────
_save_fig('Atlas_FigS3_GasPhase')
