"""
atlas_v1_verify_final.py
Complete mathematical verification for Atlas_Main_v1.tex
All equations, chi values, RRKM connection, and PCET isotope claims.

Run before any submission. All tests must PASS.
"""

import math, sys

PASS = 0; FAIL = 0; NOTES = []

HC_EV_CM  = 1.23984193e-4
C_CM_S    = 2.99792458e10
EV_TO_J   = 1.602176634e-19
AMU_TO_KG = 1.66053906660e-27
ANG_TO_M  = 1e-10
PS_TO_S   = 1e-12

def eta(chi):
    return 2*chi / (1 + chi**2)

def chi_a(dnu, nu):
    return dnu / (2*nu)

def chi_c(gamma_ev, nu_cm1):
    return gamma_ev / (2 * HC_EV_CM * nu_cm1)

def chi_b(tau_ps, lam_ev, dq_ang, m_amu, omega_s_cm1):
    tau   = tau_ps   * PS_TO_S
    lam   = lam_ev   * EV_TO_J
    dq    = dq_ang   * ANG_TO_M
    m     = m_amu    * AMU_TO_KG
    ws    = omega_s_cm1 * 2*math.pi * C_CM_S
    w0    = math.sqrt(2*lam / (m * dq**2))
    return (ws**2 * tau) / (2*w0)

def ivr_cm1(tau_s):
    return 1.0 / (2*math.pi * C_CM_S * tau_s)

def check(label, got, exp, tol=1e-3):
    global PASS, FAIL
    if exp == 0:
        ok = abs(got) < tol
    else:
        ok = abs(got - exp) / abs(exp) < tol
    sym = "PASS" if ok else "FAIL"
    if ok: PASS += 1
    else:  FAIL += 1
    if ok:
        print(f"  [PASS] {label}")
    else:
        print(f"  [FAIL] {label}")
        print(f"         got={got:.8g}  exp={exp:.8g}")

def check_range(label, v, lo, hi):
    global PASS, FAIL
    if lo <= v <= hi:
        PASS += 1
        print(f"  [PASS] {label}  ({v:.5g} in [{lo},{hi}])")
    else:
        FAIL += 1
        print(f"  [FAIL] {label}  ({v:.5g} NOT in [{lo},{hi}])")

def check_abs(label, got, tol):
    global PASS, FAIL
    if abs(got) < tol:
        PASS += 1
        print(f"  [PASS] {label}  (|{got:.3e}| < {tol:.0e})")
    else:
        FAIL += 1
        print(f"  [FAIL] {label}  (|{got:.3e}| >= {tol:.0e})")

print("="*65)
print("BLOCK 1: CORE FUNCTIONS")
print("="*65)
check("η(1.0) = 1.000",          eta(1.0),   1.0)
check("η(0.8) = 0.9756",         eta(0.8),   0.97561, tol=1e-4)
check("η(1.3) = 0.9665",         eta(1.3),   0.96654, tol=1e-4)
check_range("η(0.8) ≥ 0.95",     eta(0.8),   0.95, 1.0)
check_range("η(1.3) ≥ 0.95",     eta(1.3),   0.95, 1.0)

t = 0.95; d = math.sqrt(1-t**2)
chi_lo = (1-d)/t;  chi_hi = (1+d)/t
check("Schematic lower root = 0.7239", chi_lo, 0.7239, tol=1e-3)
check("Schematic upper root = 1.3813", chi_hi, 1.3813, tol=1e-3)

# T1.5 — use absolute error (expected=0 breaks relative error)
chi_test = 1e-3
abs_err = abs(eta(chi_test) - 2*chi_test)
check_abs("T1.5 η≈2χ approx error at χ=1e-3 (|err|<1e-8)", abs_err, 1e-8)

check("HC_EV_CM = h·c (eV·cm)",
      HC_EV_CM, 6.62607015e-34*2.99792458e10/1.602176634e-19, tol=1e-6)
check("τ=3ps → Γ=1.770 cm⁻¹", ivr_cm1(3e-12), 1.770, tol=1e-3)

print()
print("="*65)
print("BLOCK 2: SOLID-STATE SYSTEMS")
print("="*65)
check("N₂/K-Fe(111) χ = 1.2825",       chi_c(0.45, 1415),     1.2825)
check("η(K-Fe) = 0.9698",               eta(chi_c(0.45,1415)), 0.9698, tol=1e-3)
check_range("K-Fe in [0.8,1.3]",        chi_c(0.45,1415),      0.8, 1.3)
check("Fe(111) bare χ = 0.0960",        chi_c(0.05, 2100),     0.0960, tol=1e-3)
check("Fe(110) χ = 0.6049",             chi_c(0.30, 2000),     0.6049, tol=1e-3)
check("CO/Cu central χ = 0.0189",       chi_a(13, 344),        0.0189, tol=1e-3)
check("CO/Cu lower χ = 0.01453",        chi_a(10, 344),        0.01453,tol=1e-3)
check("CO/Cu upper χ = 0.02616",        chi_a(18, 344),        0.02616,tol=1e-3)
check("Li/LLZO central χ = 0.1175",     chi_a(55, 234),        0.1175, tol=1e-3)
check("Li/LLZO lower χ = 0.0714",       chi_a(40, 280),        0.0714, tol=1e-3)
check("Li/LLZO upper χ = 0.2000",       chi_a(80, 200),        0.2000, tol=1e-3)

print()
print("="*65)
print("BLOCK 3: LIQUID-PHASE SYSTEMS")
print("="*65)
L,D,M,O = 0.68, 0.40, 150.0, 100.0
chi_fe_mecn  = chi_b(0.20, L, D, M, O)
chi_fe_h2o   = chi_b(0.28, L, D, M, O)
chi_fe_etoh  = chi_b(16.0, L, D, M, O)
check("Fe(CN)₆/MeCN χ = 1.517",  chi_fe_mecn,  1.5174, tol=1e-3)
check("Fe(CN)₆/H₂O χ = 2.124",  chi_fe_h2o,   2.1244, tol=1e-3)
check("Relative MeCN/H₂O = τ ratio", chi_fe_mecn/chi_fe_h2o, 0.20/0.28)
check("Relative EtOH/MeCN = τ ratio",chi_fe_etoh/chi_fe_mecn, 16.0/0.20)

L2,D2,M2 = 0.52, 0.30, 120.0
chi_sn1_h2o  = chi_b(0.28, L2, D2, M2, O)
chi_sn1_mecn = chi_b(0.20, L2, D2, M2, O)
chi_sn1_etoh = chi_b(16.0, L2, D2, M2, O)
check("t-BuCl/H₂O χ = 1.630",   chi_sn1_h2o,  1.6296, tol=1e-3)
check("t-BuCl/MeCN χ = 1.164",  chi_sn1_mecn, 1.1640, tol=1e-3)
check("t-BuCl/EtOH χ = 93.1",   chi_sn1_etoh, 93.12,  tol=1e-2)
check("SN1 rate order: MeCN < H₂O < EtOH",
      int(chi_sn1_mecn < chi_sn1_h2o < chi_sn1_etoh), 1)

chi_hpts_a     = chi_a(160, 2750)
chi_hpts_h2o   = chi_b(0.28, 0.25, 0.50, 1.008, 200)  # H route B (proton mass)
chi_hpts_d2o   = chi_b(0.44, 0.25, 0.50, 2.014, 200)  # D route B (deuteron mass)
check("HPTS Route A χ = 0.0291",       chi_hpts_a,    0.0291, tol=1e-3)
check("HPTS H₂O Route B χ = 1.436",   chi_hpts_h2o,  1.436,  tol=1e-2)
check("HPTS D₂O Route B χ = 3.190",   chi_hpts_d2o,  3.190,  tol=1e-2)

# D/H ratio analysis — now with correct masses
dh_ratio_routeB = chi_hpts_d2o / chi_hpts_h2o
dh_ratio_taL    = 0.44 / 0.28
sqrt2           = math.sqrt(2)
print(f"\n  NOTE: HPTS D/H isotope analysis")
print(f"    Route B D/H (with masses)   = {dh_ratio_routeB:.4f}")
print(f"    τ_L(D₂O)/τ_L(H₂O) alone    = {dh_ratio_taL:.4f}")
print(f"    Mass contribution sqrt(m_H/m_D)^(-1/2) = {math.sqrt(2.014/1.008):.4f}")
print(f"    ARD proton-mass upper bound √2 = {sqrt2:.4f}")
print(f"    Route B D/H ({dh_ratio_routeB:.4f}) > √2: solvent τ_L isotope effect")
print(f"    dominates; both effects increase χ, combined ratio > √2.")
print(f"    MANUSCRIPT CORRECTION: do not claim 'agreement'; state Route B")
print(f"    captures τ_L + mass effects; combined ratio legitimately > √2.")
check_range("D/H > 1 (D more overdamped than H)", dh_ratio_routeB, 1.0, 1e6)
check("ARD mass-only bound: m_D/m_H factor = √2",
      math.sqrt(2.014/1.008), sqrt2, tol=5e-3)

print()
print("="*65)
print("BLOCK 4: GAS-PHASE SYSTEMS")
print("="*65)
chi_cp_lo  = chi_a(3,  1070); chi_cp_mid = chi_a(8,  1070); chi_cp_hi = chi_a(15,1070)
check("Cyclopropane χ lo  = 0.00140", chi_cp_lo,  0.001402, tol=1e-3)
check("Cyclopropane χ mid = 0.00374", chi_cp_mid, 0.003738, tol=1e-3)
check("Cyclopropane χ hi  = 0.00701", chi_cp_hi,  0.007009, tol=1e-3)
check_range("All cyclopropane χ << 0.8", chi_cp_hi, 0, 0.8)
N_cp = 1.0/eta(chi_cp_mid)
check("Cyclopropane N_encounters ≈ 134", N_cp, 134, tol=0.02)

chi_no2_lo = chi_a(3, 850); chi_no2_mid = chi_a(10,800); chi_no2_hi = chi_a(20,750)
check("NO₂ χ lo  = 0.00176", chi_no2_lo,  0.001765, tol=1e-3)
check("NO₂ χ mid = 0.00625", chi_no2_mid, 0.006250, tol=1e-3)
check("NO₂ χ hi  = 0.01333", chi_no2_hi,  0.013333, tol=1e-3)

gamma_menc = ivr_cm1(3e-12)
check("τ_IVR=3ps → Γ=1.770 cm⁻¹",     gamma_menc,    1.770,  tol=1e-3)
chi_menc_lo = chi_a(1.5, 510); chi_menc_mid = chi_a(gamma_menc,460); chi_menc_hi = chi_a(5,400)
check("CH₃NC χ lo  = 0.00147", chi_menc_lo,  0.001471, tol=1e-3)
check("CH₃NC χ mid = 0.00192", chi_menc_mid, 0.001923, tol=1e-3)
check("CH₃NC χ hi  = 0.00625", chi_menc_hi,  0.006250, tol=1e-3)
check_range("All gas-phase χ < 0.1", chi_no2_hi, 0, 0.1)

print()
print("="*65)
print("BLOCK 5: RRKM CONNECTION")
print("="*65)
check("P_commit = η(χ) at χ=0.001", eta(1e-3), 2e-3/(1+(1e-3)**2), tol=1e-8)
check_abs("Small-χ approx error at χ=0.001 (|err|<1e-8)", 
          abs(eta(1e-3) - 2e-3), 1e-8)
check("N_encounters at χ=0.001 = 500",  1/eta(1e-3), 500, tol=0.01)
check("N_encounters at χ=0.01  = 50",   1/eta(0.01), 50,  tol=0.01)
check("Gas/liquid χ ratio > 100×",
      int(chi_sn1_h2o/chi_cp_mid > 100), 1)
print(f"  Gas/liquid representative ratio: {chi_sn1_h2o/chi_cp_mid:.0f}×  "
      f"= {math.log10(chi_sn1_h2o/chi_cp_mid):.1f} decades")

print()
print("="*65)
print("BLOCK 6: PCET ISOTOPE")
print("="*65)
chi_h = 0.90
check("χ_D = √2·χ_H formula", math.sqrt(2)*chi_h, 1.2728, tol=1e-4)
check("Mass derivation: Ω₀_D = Ω₀_H/√2",
      1000/math.sqrt(2.014/1.008), 1000/math.sqrt(2), tol=5e-3)
check("χ_D/χ_H from mass alone = √2",
      (100/(2*(1000/math.sqrt(2)))) / (100/(2*1000)), math.sqrt(2), tol=1e-6)

print()
print("="*65)
print("BLOCK 7: NINE-SYSTEM TABLE")
print("="*65)
atlas = [
    ("N2/K-Fe111",    chi_c(0.45,1415),  1.2825,  "near-crit"),
    ("CO/Cu111",      chi_a(13,344),     0.01890, "underdamped"),
    ("Li/LLZO",       chi_a(55,234),     0.1175,  "underdamped"),
    ("Fe(CN)6/MeCN",  chi_fe_mecn,       1.5174,  "overdamped"),
    ("tBuCl/H2O",     chi_sn1_h2o,       1.6296,  "overdamped"),
    ("HPTS/H2O(B)",   chi_hpts_h2o,      1.436,   "overdamped"),
    ("Cyclopropane",  chi_cp_mid,        0.003738,"underdamped"),
    ("NO2",           chi_no2_mid,       0.006250,"underdamped"),
    ("CH3NC",         chi_menc_mid,      0.001923,"underdamped"),
]
print(f"\n  {'System':<20} {'χ₀':>10}  {'Expected':>10}  {'Status':<6}  Regime")
print("  "+"-"*60)
for name, got, exp, regime in atlas:
    ok = abs(got-exp)/exp < 1e-3
    sym = "PASS" if ok else "FAIL"
    if ok: PASS += 1
    else:  FAIL += 1
    print(f"  {name:<20} {got:>10.5f}  {exp:>10.5f}  [{sym}]   {regime}")

print()
print("="*65)
print("FINAL SUMMARY")
print("="*65)
print(f"  PASS: {PASS}  |  FAIL: {FAIL}")
if FAIL == 0:
    print("  STATUS: ALL TESTS PASSED ✓  — manuscript numbers verified")
    print()
    print("  MANUSCRIPT CORRECTION REQUIRED (not a numeric error):")
    print("  Section 4.3 (HPTS): Remove 'in agreement with the Route B")
    print("  D₂O estimate'. Replace with:")
    print("  'Route B with D₂O gives χ_D ≈ 3.19, exceeding the proton-")
    print("  dominated ARD upper bound (√2·χ_H ≈ 2.03). The excess arises")
    print("  from the solvent isotope effect on τ_L: τ_L(D₂O)/τ_L(H₂O) =")
    print("  1.57 > √2 in H-bonded water, amplifying the proton-mass")
    print("  contribution. Both effects increase χ on deuteration.'")
else:
    print("  STATUS: FAILURES DETECTED — do not submit")
    sys.exit(1)
