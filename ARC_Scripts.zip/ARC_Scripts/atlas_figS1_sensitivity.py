"""
atlas_figS1_sensitivity.py
Route B sensitivity heatmap (Supplementary Figure S1)

Shows χ₀ for Fe(CN)₆³⁻/⁴⁻ / MeCN across a grid of m_eff and Ω_s values.
Central estimate: χ₀ = 1.52 at m_eff = 150 amu, Ω_s = 100 cm⁻¹.
Near-critical window contours (χ₀ = 0.8 and 1.3) overlaid.

Purpose: demonstrates that the absolute Route B placement is bracket-dependent
while the relative solvent ordering remains Tier 1.

Run in Google Colab:  !python atlas_figS1_sensitivity.py
Saves:  Atlas_FigS1_Sensitivity.svg  and  Atlas_FigS1_Sensitivity.png
"""

import math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ── COLAB-AWARE SAVE WITH EDITABLE SVG TEXT ───────────────────────
# svg.fonttype = 'none' writes SVG <text> elements instead of path
# outlines. Labels open as editable text strings in Adobe Illustrator.
plt.rcParams['svg.fonttype'] = 'none'

import os as _os

def _save_fig(basename):
    """Save SVG (editable text) and PNG (300 dpi).
    Detects Google Colab and saves to /content/ so files appear
    in the Colab file browser (left panel) for download.
    """
    try:
        import google.colab          # noqa: F401
        out_dir = '/content'
        _in_colab = True
    except ImportError:
        out_dir = _os.getcwd()
        _in_colab = False

    svg_out = _os.path.join(out_dir, basename + '.svg')
    png_out = _os.path.join(out_dir, basename + '.png')

    plt.savefig(svg_out, bbox_inches='tight')
    plt.savefig(png_out, bbox_inches='tight', dpi=300)

    print(f"Saved SVG: {svg_out}  (text editable in Illustrator)")
    print(f"Saved PNG: {png_out}  (300 dpi)")

    if _in_colab:
        print("Download: right-click the file in the Colab file browser,")
        print("  or run:  from google.colab import files")
        print(f" files.download('{svg_out}')")


# ── STYLE ─────────────────────────────────────────────────────────
plt.rcParams.update({
    'svg.fonttype': 'none',   # keeps text editable in Illustrator
    'font.family':     'serif',
    'font.size':       10,
    'axes.linewidth':  0.8,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
})

# ── CONSTANTS ─────────────────────────────────────────────────────
C_CM_S    = 2.99792458e10
EV_TO_J   = 1.602176634e-19
AMU_TO_KG = 1.66053906660e-27
ANG_TO_M  = 1e-10
PS_TO_S   = 1e-12

def chi_route_b(tau_ps, lam_ev, dq_ang, m_amu, omega_s_cm1):
    """Route B absolute χ₀."""
    tau = tau_ps   * PS_TO_S
    lam = lam_ev   * EV_TO_J
    dq  = dq_ang   * ANG_TO_M
    m   = m_amu    * AMU_TO_KG
    ws  = omega_s_cm1 * 2 * math.pi * C_CM_S
    w0  = math.sqrt(2 * lam / (m * dq ** 2))
    return (ws ** 2 * tau) / (2 * w0)

# ── PARAMETERS ────────────────────────────────────────────────────
# Fe(CN)₆³⁻/⁴⁻ in MeCN
# λ = 0.68 eV (Grampp & Jaenicke 1990)
# ΔQ = 0.40 Å
# τ_L(MeCN) = 0.20 ps (Jimenez et al. 1994)
LAM = 0.68
DQ  = 0.40
TAU = 0.20

m_vals  = np.array([50, 100, 150, 200, 300, 500])   # amu
ws_vals = np.array([50,  75, 100, 125, 150])          # cm⁻¹

# Compute grid
grid = np.zeros((len(ws_vals), len(m_vals)))
for i, ws in enumerate(ws_vals):
    for j, m in enumerate(m_vals):
        grid[i, j] = chi_route_b(TAU, LAM, DQ, m, ws)

# ── FIGURE ────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(6.0, 4.2))

# Heatmap on log₁₀ scale
im = ax.imshow(
    np.log10(grid),
    aspect='auto',
    origin='lower',
    cmap='RdYlGn_r',
    vmin=np.log10(0.01),
    vmax=np.log10(15),
    extent=[-0.5, len(m_vals) - 0.5, -0.5, len(ws_vals) - 0.5],
)

# Cell annotations
for i in range(len(ws_vals)):
    for j in range(len(m_vals)):
        v = grid[i, j]
        # White text on dark backgrounds
        txt_col = 'white' if (v < 0.25 or v > 6) else 'black'
        ax.text(j, i, f'{v:.2f}', ha='center', va='center',
                fontsize=8, color=txt_col, fontweight='bold')

# Near-critical window contours
CS = ax.contour(
    np.log10(grid),
    levels=[math.log10(0.8), math.log10(1.3)],
    colors=['#3a86ff', '#ffd166'],
    linewidths=2.2,
    linestyles=[':', '--'],
)
fmt = {CS.levels[0]: 'χ₀ = 0.8', CS.levels[1]: 'χ₀ = 1.3'}
# clabel doesn't accept fontproperties; set font on the resulting text objects
CS_labels = ax.clabel(CS, fmt=fmt, fontsize=8.5,
          colors=['#3a86ff', '#cc9900'])
for txt in CS_labels:
    txt.set_fontfamily('Cambria Math')

# Central estimate marker
ax.plot(2, 2, '*', ms=14, color='white', mec='#333333', mew=1.0,
        zorder=5, label=f'Central: χ₀ = {grid[2,2]:.2f}')
ax.legend(fontsize=9, loc='upper left', framealpha=0.85)

ax.set_xticks(range(len(m_vals)))
ax.set_xticklabels([str(m) for m in m_vals], fontsize=9.5)
ax.set_yticks(range(len(ws_vals)))
ax.set_yticklabels([str(w) for w in ws_vals], fontsize=9.5)
ax.set_xlabel(r'$m_{\mathrm{eff}}$ (amu)', fontsize=10.5)
ax.set_ylabel(r'$\Omega_s$ (cm$^{-1}$)', fontsize=10.5)

cbar = fig.colorbar(im, ax=ax, pad=0.02)
cbar.set_label(r'$\log_{10}\,\chi_0$', fontsize=9.5)

ax.set_title(
    'Route B sensitivity: Fe(CN)₆³⁻/⁴⁻/MeCN'
    '\n'
    '(λ = 0.68 eV, ΔQ = 0.40 Å, τ_L = 0.20 ps)',
    fontsize=9.5)

ax.text(0.50, -0.18,
        'Relative solvent ordering is Tier 1 regardless of bracket.  '
        'Absolute χ₀ placement is Tier 2.',
        fontfamily='Cambria Math',
        transform=ax.transAxes, ha='center', fontsize=8,
        color='#444444', style='italic')

plt.tight_layout(pad=1.0)

# ── SAVE ──────────────────────────────────────────────────────────
_save_fig('Atlas_FigS1_Sensitivity')
