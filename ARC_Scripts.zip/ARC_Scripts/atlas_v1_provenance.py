"""
atlas_v1_provenance.py
Input provenance and anti-forcing demonstration

For each of the nine atlas systems, this script:
  1. Lists the exact literature source for every input parameter
  2. Computes chi_0 from those inputs
  3. Reports regime (underdamped / near-critical / overdamped)
  4. Performs a sensitivity test: how much must the primary input
     parameter change to cross the nearest regime boundary?

PURPOSE: demonstrate that chi_0 values were not tuned to produce
desired results. Parameters come from independent literature sources.
The regime assignments follow from the calculation, not the reverse.

ANTI-FORCING EVIDENCE IN THIS OUTPUT:
  - Only N2/K-Fe(111) is inside [0.8, 1.3] — the near-critical window.
    All other systems are either deeply underdamped or overdamped.
  - Gas-phase systems are underdamped by 2-3 orders of magnitude.
    No adjustment of Gamma_IVR within any physically plausible range
    can move them into the near-critical window.
  - Liquid systems (fastest solvents) are slightly overdamped (1.4-1.6),
    not inside the window. This is NOT a cherry-picked result.
  - CO/Cu is underdamped. LLZO is underdamped. This would not appear
    in a forced dataset.

Run in Google Colab:  !python atlas_v1_provenance.py
"""

import math, sys

# ── CONSTANTS (canonical, verified in atlas_v1_verify_final.py) ───
HC_EV_CM  = 1.23984193e-4    # eV·cm  (h·c in spectroscopy units)
C_CM_S    = 2.99792458e10    # cm/s
EV_TO_J   = 1.602176634e-19  # J/eV (exact, SI 2019)
AMU_TO_KG = 1.66053906660e-27
ANG_TO_M  = 1e-10
PS_TO_S   = 1e-12

def chi_a(dnu_L, nu):
    """Route A: chi = Delta_nu_L / (2 * nu)"""
    return dnu_L / (2.0 * nu)

def chi_c(gamma_ev, nu_cm1):
    """Route C: chi = Gamma_NN / (2 * hc * nu)"""
    return gamma_ev / (2.0 * HC_EV_CM * nu_cm1)

def chi_b(tau_ps, lam_ev, dq_ang, m_amu, omega_s_cm1):
    """Route B absolute chi (Tier 2 absolute; Tier 1 relative)."""
    tau = tau_ps * PS_TO_S
    lam = lam_ev * EV_TO_J
    dq  = dq_ang * ANG_TO_M
    m   = m_amu  * AMU_TO_KG
    ws  = omega_s_cm1 * 2 * math.pi * C_CM_S
    w0  = math.sqrt(2 * lam / (m * dq ** 2))
    return (ws ** 2 * tau) / (2 * w0)

def ivr_cm1(tau_s):
    """Convert IVR lifetime (s) to linewidth Gamma_IVR (cm^-1)."""
    return 1.0 / (2 * math.pi * C_CM_S * tau_s)

def regime(chi):
    if chi < 0.8:   return "UNDERDAMPED"
    elif chi > 1.3: return "OVERDAMPED"
    else:           return "NEAR-CRITICAL"

def sensitivity(chi_central, chi_boundary, input_name, input_val,
                chi_fn, chi_fn_kwargs, param_key):
    """Fraction by which the primary input must change to cross
    the nearest boundary (0.8 or 1.3)."""
    boundary = 0.8 if chi_central < 0.8 else 1.3
    # chi scales linearly with the primary input for Routes A and C
    # (chi = input * constant), so:
    factor = boundary / chi_central
    pct = abs(factor - 1.0) * 100
    direction = "increase" if factor > 1 else "decrease"
    return factor, pct, direction, boundary

# ── SYSTEM DEFINITIONS WITH FULL PROVENANCE ───────────────────────

print("=" * 72)
print("ATLAS PARAMETER PROVENANCE AND ANTI-FORCING ANALYSIS")
print("=" * 72)
print()
print("For each system: input source → chi_0 value → regime → sensitivity")
print("Brackets show full uncertainty range from manuscript.")
print()

systems = [

    # ── SOLID-STATE ────────────────────────────────────────────────
    {
        "name":    "N2 on K-Fe(111)",
        "phase":   "Surface",
        "route":   "C",
        "tier":    "2",
        "inputs": {
            "Gamma_NN (eV)":  0.45,
            "nu_tilde (cm-1)": 1415,
        },
        "input_sources": {
            "Gamma_NN": "DFT d-band electronic structure; methodology from "
                        "Maurer et al. PRB 94, 115432 (2016). "
                        "Values from ARD companion (Christensen 2026 ChemRxiv "
                        "DOI 10.26434/chemrxiv.15004963/v1).",
            "nu_tilde": "N-N stretch frequency on K-promoted Fe(111) surface; "
                        "consistent with experimental HREELS for "
                        "N2/Fe systems.",
        },
        "chi_central": chi_c(0.45, 1415),
        "chi_lo":      chi_c(0.35, 1480),   # conservative DFT bracket
        "chi_hi":      chi_c(0.60, 1350),
        "note": "ONLY system inside the near-critical window [0.8, 1.3]. "
                "Parameter chi=1.2825 follows from DFT inputs, not chosen "
                "to produce this result.",
    },
    {
        "name":    "CO on Cu(111)",
        "phase":   "Surface",
        "route":   "A",
        "tier":    "1",
        "inputs": {
            "Delta_nu_L (cm-1)": 13.0,
            "nu_perp (cm-1)":    344.0,
        },
        "input_sources": {
            "Delta_nu_L": "Lorentzian FWHM of Cu-CO perpendicular stretch "
                          "from temperature-dependent IRAS/HREELS. "
                          "Hirschmugl et al. PRL 65, 480 (1990); "
                          "Persson & Ryberg PRB 32, 3586 (1985). "
                          "Range 10-18 cm-1; 13 is central. Tier 1.",
            "nu_perp":    "Cu-CO perpendicular stretch frequency from HREELS. "
                          "Hirschmugl et al. (1990). Lorentzian fraction "
                          ">60% at low T, satisfying Route A validity.",
        },
        "chi_central": chi_a(13.0, 344.0),
        "chi_lo":      chi_a(10.0, 344.0),
        "chi_hi":      chi_a(18.0, 344.0),
        "note": "Deeply underdamped. Consistent with low sticking probability "
                "S0 ~ 0.3-0.5 on Cu(111).",
    },
    {
        "name":    "Li+ in LLZO",
        "phase":   "Solid",
        "route":   "C-analog",
        "tier":    "3",
        "inputs": {
            "Gamma_ph (cm-1)": 55.0,
            "nu_0 (cm-1)":     234.0,
        },
        "input_sources": {
            "Gamma_ph": "Phonon friction kernel from MD velocity-autocorrelation. "
                        "Kozinsky et al. PRL 116, 055901 (2016). "
                        "Range 40-80 cm-1; Tier 3 (MD-derived).",
            "nu_0":     "Li cage-rattling mode ~7 THz from neutron spectroscopy. "
                        "Wood et al. PRMater 2, 065401 (2018). "
                        "Range 200-280 cm-1.",
        },
        "chi_central": chi_a(55.0, 234.0),
        "chi_lo":      chi_a(40.0, 280.0),
        "chi_hi":      chi_a(80.0, 200.0),
        "note": "Tier 3 prospective. Upper bracket chi_max = 0.20 < 0.8: "
                "underdamped assignment is regime-stable across full bracket.",
    },

    # ── LIQUID PHASE ───────────────────────────────────────────────
    {
        "name":    "Fe(CN)6 ET in MeCN",
        "phase":   "Liquid",
        "route":   "B",
        "tier":    "1r/2a",
        "inputs": {
            "tau_L_MeCN (ps)": 0.20,
            "lambda (eV)":     0.68,
            "DeltaQ (Ang)":    0.40,
            "m_eff (amu)":     150.0,
            "Omega_s (cm-1)":  100.0,
        },
        "input_sources": {
            "tau_L":   "Longitudinal relaxation time from femtosecond "
                       "solvation dynamics. Jimenez et al. Nature 369, 471 (1994). "
                       "Tier 1.",
            "lambda":  "Outer-sphere reorganization energy. "
                       "Grampp & Jaenicke Ber. Bunsenges. 95, 904 (1991). "
                       "Tier 1.",
            "DeltaQ":  "Charge-coordinate displacement; estimated from "
                       "Born model and Marcus theory. Tier 2.",
            "m_eff":   "Collective solvation-shell mass bracket "
                       "50-500 amu (single molecule to first shell). "
                       "m=150 is central. Tier 2.",
            "Omega_s": "Debye-Drude bath frequency 50-150 cm-1. "
                       "Jimenez (1994); Bagchi & Oxtoby JCP 78, 2735 (1983). "
                       "Tier 2.",
        },
        "chi_central": chi_b(0.20, 0.68, 0.40, 150, 100),
        "chi_lo":      chi_b(0.20, 0.68, 0.40, 500,  50),
        "chi_hi":      chi_b(0.20, 0.68, 0.40,  50, 150),
        "note": "OUTSIDE near-critical window (chi=1.52 > 1.3, slightly "
                "overdamped). Relative ordering across solvents is Tier 1.",
    },
    {
        "name":    "t-BuCl SN1 in H2O",
        "phase":   "Liquid",
        "route":   "B",
        "tier":    "1r/2a",
        "inputs": {
            "tau_L_H2O (ps)": 0.28,
            "lambda (eV)":    0.52,
            "DeltaQ (Ang)":   0.30,
            "m_eff (amu)":    120.0,
            "Omega_s (cm-1)": 100.0,
        },
        "input_sources": {
            "tau_L":  "Jimenez et al. (1994). Tier 1.",
            "lambda": "Marcus Born model estimate for C-Cl ionization. Tier 2.",
            "DeltaQ": "C-Cl ionization coordinate displacement; estimated. "
                      "Tier 2.",
            "m_eff":  "Solvation shell inertia bracket. Tier 2.",
            "rate_ref": "Winstein & Fainberg JACS 78, 2770 (1956) "
                        "for rate order verification.",
        },
        "chi_central": chi_b(0.28, 0.52, 0.30, 120, 100),
        "chi_lo":      chi_b(0.28, 0.52, 0.30, 500,  50),
        "chi_hi":      chi_b(0.28, 0.52, 0.30,  50, 150),
        "note": "OUTSIDE near-critical window (chi=1.63 > 1.3, slightly "
                "overdamped). MeCN gives chi=1.16 (closer to window). "
                "Rate inversion vs. MeCN reflects thermodynamic masking "
                "(ion-pair stabilization), not framework failure.",
    },
    {
        "name":    "HPTS proton transfer in H2O",
        "phase":   "Liquid",
        "route":   "A+B",
        "tier":    "2/diag",
        "inputs": {
            "nu_OH* (cm-1)":    2750.0,
            "Delta_nu_L (cm-1)": 160.0,
            "tau_L_H2O (ps)":    0.28,
            "m_H (amu)":         1.008,
            "lambda (eV)":       0.25,
            "DeltaQ (Ang)":      0.50,
            "Omega_s (cm-1)":    200.0,
        },
        "input_sources": {
            "nu_OH*":     "Excited-state O-H stretch from 2D-IR. "
                          "Spry & Fayer JCP 127, 204501 (2007). Tier 2/diag "
                          "(Lorentzian fraction ~40% < 50% threshold).",
            "Delta_nu_L": "Lorentzian FWHM; ~40% of total FWHM 400 cm-1. "
                          "Route A diagnostic only.",
            "tau_L":      "Jimenez et al. (1994). Tier 1.",
            "m_H":        "Proton mass (nucleus transferred). Fixed.",
            "lambda":     "Estimated for proton-transfer reorganization. "
                          "Tier 2.",
        },
        "chi_central": chi_b(0.28, 0.25, 0.50, 1.008, 200),
        "chi_lo":      chi_b(0.28, 0.25, 0.50, 2.000, 200),
        "chi_hi":      chi_b(0.28, 0.25, 0.50, 0.800, 200),
        "note": "Route B (chi=1.44) carries main interpretation. "
                "Route A (chi=0.029) diagnostic; below >50% Lor. threshold. "
                "D2O: chi_D=3.19 > sqrt(2)*chi_H (solvent tau_L effect dominates).",
    },

    # ── GAS PHASE ──────────────────────────────────────────────────
    {
        "name":    "Cyclopropane -> propene",
        "phase":   "Gas",
        "route":   "A (IVR)",
        "tier":    "2",
        "inputs": {
            "Gamma_IVR (cm-1)": 8.0,
            "nu_ring (cm-1)":   1070.0,
        },
        "input_sources": {
            "Gamma_IVR": "IVR linewidth from RRKM density-of-states at "
                         "threshold energy. Rabinovitch & Setser "
                         "Adv. Photochem. 3, 1 (1964). Range 3-15 cm-1. "
                         "Tier 2 (RRKM-derived, not directly measured).",
            "nu_ring":   "C-C ring-breathing mode from gas-phase IR. "
                         "Rabinovitch (1964). Directly measured.",
        },
        "chi_central": chi_a(8.0, 1070.0),
        "chi_lo":      chi_a(3.0, 1070.0),
        "chi_hi":      chi_a(15.0, 1070.0),
        "note": "Deeply underdamped. IVR-as-friction is a structural "
                "analogy (non-Markovian quantum process mapped to "
                "classical generator). P_commit ~ 2*chi ~ 0.7% per encounter.",
    },
    {
        "name":    "NO2 -> NO + O predissociation",
        "phase":   "Gas",
        "route":   "A (Lorentzian)",
        "tier":    "1",
        "inputs": {
            "Gamma_pd (cm-1)":      10.0,
            "nu_approach (cm-1)":   800.0,
        },
        "input_sources": {
            "Gamma_pd": "State-resolved Lorentzian FWHM from REMPI "
                        "photofragment spectroscopy near threshold. "
                        "Ionov et al. JCP 97, 9486 (1992). "
                        "Range 3-20 cm-1. TIER 1: directly measured "
                        "lifetime-broadened Lorentzian.",
            "nu_approach": "Anharmonically softened N-O symmetric stretch "
                           "near D0=25576 cm-1. Range 750-850 cm-1. "
                           "Ionov (1992).",
        },
        "chi_central": chi_a(10.0, 800.0),
        "chi_lo":      chi_a(3.0,  850.0),
        "chi_hi":      chi_a(20.0, 750.0),
        "note": "ONLY Tier 1 gas-phase entry (directly measured Lorentzian). "
                "Near-unit quantum yield above threshold is consistent "
                "with irreversible coupling to dissociative continuum.",
    },
    {
        "name":    "CH3NC -> CH3CN",
        "phase":   "Gas",
        "route":   "A (IVR)",
        "tier":    "2",
        "inputs": {
            "tau_IVR (ps)":          3.0,
            "nu_approach (cm-1)":    460.0,
        },
        "input_sources": {
            "tau_IVR": "IVR time from state-resolved fluorescence. "
                       "Reddy & Berry Chem. Phys. Lett. 66, 223 (1979). "
                       "Tier 2.",
            "nu_approach": "C-N-C bending / CN approach mode near TS. "
                           "Farantos et al. JCP 101, 8520 (1994). "
                           "Range 400-510 cm-1.",
        },
        "chi_central": chi_a(ivr_cm1(3e-12), 460.0),
        "chi_lo":      chi_a(1.5, 510.0),
        "chi_hi":      chi_a(5.0, 400.0),
        "note": "Most deeply underdamped system in atlas. "
                "IVR tau=3ps -> Gamma=1.77 cm-1 (verified: "
                "1/(2*pi*c*tau) = 1/(2*pi*2.998e10*3e-12) = 1.770 cm-1). "
                "N_encounters ~ 260: consistent with RRKM excess-energy "
                "requirement (Schneider & Rabinovitch JACS 84, 4215 (1962)).",
    },
]

# ── PRINT PROVENANCE TABLE ─────────────────────────────────────────
near_crit_count = 0
forced_concern  = []

for s in systems:
    chi = s["chi_central"]
    reg = regime(chi)
    if reg == "NEAR-CRITICAL":
        near_crit_count += 1

    print(f"{'─'*72}")
    print(f"SYSTEM: {s['name']}  [{s['phase']}]  Route {s['route']}  Tier {s['tier']}")
    print(f"  chi_0: {chi:.5f}  ({s['chi_lo']:.5f} – {s['chi_hi']:.5f})")
    print(f"  Regime: {reg}")

    # Sensitivity: how far to nearest boundary?
    boundary = 0.8 if chi <= 1.05 else 1.3
    factor_needed = boundary / chi
    pct_change    = abs(factor_needed - 1.0) * 100
    direction     = "increase" if factor_needed > 1 else "decrease"
    primary_input = list(s["inputs"].keys())[0]
    primary_val   = list(s["inputs"].values())[0]
    print(f"  Sensitivity: primary input must {direction} by "
          f"{pct_change:.0f}% to cross chi={boundary:.1f} boundary")
    print(f"    ({primary_input} = {primary_val} → "
          f"would need {primary_val * factor_needed:.3f})")

    if pct_change < 20:
        forced_concern.append((s['name'], pct_change, boundary))

    print(f"  Note: {s['note']}")

    # Print input sources
    print(f"  Input sources:")
    for param, source in s["input_sources"].items():
        print(f"    {param}: {source[:70]}")
        if len(source) > 70:
            print(f"           {source[70:140]}")

print()
print("=" * 72)
print("SUMMARY")
print("=" * 72)
print(f"Systems inside near-critical window [0.8, 1.3]: "
      f"{near_crit_count} of {len(systems)}")
print(f"  (Only N2/K-Fe; all others underdamped or overdamped)")
print()

if forced_concern:
    print("SENSITIVITY FLAGS (primary input change < 20% to cross boundary):")
    for name, pct, bnd in forced_concern:
        print(f"  {name}: {pct:.0f}% change needed to reach chi={bnd}")
    print("  These require careful provenance documentation.")
else:
    print("No sensitivity flags: all systems require >20% parameter change")
    print("to cross the nearest regime boundary.")
    print("This confirms the regime assignments are not sensitive to")
    print("small parameter variations and are not forced.")

print()
print("ANTI-FORCING EVIDENCE:")
print("  1. Gas-phase systems (chi ~ 10^-3) cannot be moved near 1.0")
print("     by any physically plausible Gamma_IVR adjustment.")
print("  2. Liquid systems (MeCN, H2O) are OUTSIDE the near-critical window.")
print("     If results were forced, these would be placed closer to 1.0.")
print("  3. CO/Cu is underdamped (chi=0.019). Forced datasets would not")
print("     include an underdamped surface system.")
print("  4. LLZO is underdamped (chi=0.12, bracket 0.07-0.20, all < 0.8).")
print("     Its inclusion as a Tier 3 negative result strengthens the atlas.")
print("  5. N2/K-Fe is the ONLY near-critical system. Its parameters come")
print("     from DFT electronic structure calculations, not from choosing")
print("     Gamma_NN to give chi=1.")
