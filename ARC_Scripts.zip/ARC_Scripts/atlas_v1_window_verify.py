"""
atlas_v1_window_verify.py
Near-critical window and eta function verification

Verifies from first principles:
  1. eta(chi) = 2*chi/(1+chi^2) — derivation from damped oscillator
  2. Analytic roots of eta(chi) = 0.95 giving schematic window [0.7239, 1.3813]
  3. Operational window [0.8, 1.3] and why it is tighter than the schematic roots
  4. Commitment probability P_commit = eta(chi) at all nine atlas chi values
  5. Small-chi approximation P_commit ~ 2*chi (gas phase)
  6. N_encounters = 1/P_commit for gas-phase systems

No literature values used. All verifications from mathematical definitions only.

Run in Google Colab:  !python atlas_v1_window_verify.py
"""

import math

# ── ETA FUNCTION ──────────────────────────────────────────────────

def eta(chi):
    """Reduced dynamical efficiency of the approach coordinate.
    Derivation: for a damped harmonic oscillator with chi = Gamma/(2*Omega_0),
    the eigenvalues are lambda = -chi*Omega_0 +/- Omega_0*sqrt(chi^2 - 1).
    At chi < 1: complex eigenvalues (oscillatory approach, recrossing-prone).
    At chi = 1: degenerate real eigenvalues (exceptional point, fastest decay).
    At chi > 1: two distinct real negative eigenvalues (overdamped).
    The efficiency eta(chi) = 2*chi/(1+chi^2) has maximum eta=1 at chi=1."""
    return 2 * chi / (1 + chi ** 2)

SEP = "─" * 60

# ── SECTION 1: KEY ETA VALUES ─────────────────────────────────────
print("=" * 60)
print("SECTION 1: KEY VALUES OF eta(chi)")
print("=" * 60)
print()
print(f"  {'chi':>10}  {'eta(chi)':>10}  Note")
print(SEP)
for chi, note in [
    (0.0,    "zero (no friction)"),
    (0.001,  "typical gas-phase"),
    (0.01,   "gas-phase upper"),
    (0.1,    "transition zone"),
    (0.7239, "analytic schematic lower root"),
    (0.8,    "operational window lower bound"),
    (1.0,    "exceptional point — maximum"),
    (1.3,    "operational window upper bound"),
    (1.3813, "analytic schematic upper root"),
    (1.52,   "Fe(CN)6/MeCN central"),
    (1.63,   "t-BuCl/H2O central"),
    (10.0,   "EtOH SN1 approximate"),
    (93.0,   "EtOH SN1 central"),
]:
    print(f"  {chi:>10.4f}  {eta(chi):>10.6f}  {note}")

# ── SECTION 2: ANALYTIC WINDOW BOUNDARIES ─────────────────────────
print()
print("=" * 60)
print("SECTION 2: ANALYTIC ROOTS OF eta(chi) = 0.95")
print("=" * 60)
print()
print("  Equation: 2*chi/(1+chi^2) = 0.95")
print("  Rearrange: 0.95*chi^2 - 2*chi + 0.95 = 0")
print("  Quadratic: chi = (2 +/- sqrt(4 - 4*0.95^2)) / (2*0.95)")
print("                 = (1 +/- sqrt(1 - 0.95^2)) / 0.95")
print()

threshold = 0.95
disc = math.sqrt(1 - threshold ** 2)
chi_lo = (1 - disc) / threshold
chi_hi = (1 + disc) / threshold

print(f"  discriminant = sqrt(1 - 0.95^2) = sqrt({1 - 0.95**2:.6f}) = {disc:.6f}")
print(f"  chi_lo (schematic) = (1 - {disc:.6f}) / 0.95 = {chi_lo:.6f}")
print(f"  chi_hi (schematic) = (1 + {disc:.6f}) / 0.95 = {chi_hi:.6f}")
print()
print(f"  Verification:")
print(f"    eta({chi_lo:.6f}) = {eta(chi_lo):.8f}  (should be 0.95000000)")
print(f"    eta({chi_hi:.6f}) = {eta(chi_hi):.8f}  (should be 0.95000000)")

assert abs(eta(chi_lo) - 0.95) < 1e-8, "Lower root verification failed"
assert abs(eta(chi_hi) - 0.95) < 1e-8, "Upper root verification failed"
print()
print("  Operational window [0.8, 1.3] is deliberately tighter than the")
print(f"  schematic roots [{chi_lo:.4f}, {chi_hi:.4f}] to provide a conservative")
print("  definition that accounts for real system uncertainties.")
print(f"  eta(0.8) = {eta(0.8):.6f}  (exceeds 0.95 ✓)")
print(f"  eta(1.3) = {eta(1.3):.6f}  (exceeds 0.95 ✓)")

# ── SECTION 3: ALL NINE ATLAS SYSTEMS ─────────────────────────────
print()
print("=" * 60)
print("SECTION 3: P_commit FOR ALL NINE ATLAS SYSTEMS")
print("=" * 60)
print()
print(f"  {'System':<28} {'chi_0':>8} {'P_commit':>10} {'N_enc':>8}  Regime")
print(SEP)

atlas_systems = [
    ("CH3NC",          0.0019),
    ("Cyclopropane",   0.0037),
    ("NO2",            0.0063),
    ("CO/Cu(111)",     0.019),
    ("Li+/LLZO",       0.118),
    ("N2/K-Fe(111)",   1.2825),
    ("HPTS/H2O (B)",   1.44),
    ("Fe(CN)6/MeCN",   1.52),
    ("t-BuCl/H2O",     1.63),
]

for name, chi in atlas_systems:
    P     = eta(chi)
    N_enc = 1.0 / P
    reg   = "NEAR-CRIT" if 0.8 <= chi <= 1.3 else \
            "underdamp" if chi < 0.8 else "overdamp"
    print(f"  {name:<28} {chi:>8.5f} {P:>10.6f} {N_enc:>8.1f}  {reg}")

# ── SECTION 4: SMALL-CHI APPROXIMATION ───────────────────────────
print()
print("=" * 60)
print("SECTION 4: SMALL-CHI APPROXIMATION P_commit ~ 2*chi")
print("=" * 60)
print()
print(f"  {'chi':>10}  {'exact eta':>12}  {'approx 2*chi':>14}  {'rel error (%)':>14}")
print(SEP)
for chi in [1e-4, 1e-3, 1e-2, 5e-2, 0.1]:
    exact   = eta(chi)
    approx  = 2 * chi
    rel_err = abs(exact - approx) / exact * 100
    print(f"  {chi:>10.4g}  {exact:>12.8f}  {approx:>14.8f}  {rel_err:>14.4f}")

print()
print("  For chi < 0.01, approximation P ~ 2*chi is accurate to < 0.01%.")
print("  This is why N_encounters ~ 1/(2*chi) is valid for gas-phase systems.")
print()
print("  Gas-phase implications:")
for name, chi in [("CH3NC",0.0019),("Cyclopropane",0.0037),("NO2",0.0063)]:
    P_exact  = eta(chi)
    P_approx = 2 * chi
    N_exact  = 1 / P_exact
    N_approx = 1 / P_approx
    print(f"    {name:<14}: chi={chi:.4f}, "
          f"P_commit={P_exact:.5f}, "
          f"N_enc(exact)={N_exact:.0f}, "
          f"N_enc(approx)={N_approx:.0f}")

print()
print("  NOTE: These N_encounters values are CLASSICAL STRUCTURAL-ANALOGY")
print("  estimates. The gas-phase IVR is a quantum interference process;")
print("  P_commit = eta(chi) applied here is a qualitative indicator,")
print("  not a rigorous quantum-mechanical first-passage probability.")
print("  The RRKM analogy is structural, not mechanistic.")

# ── SECTION 5: CONSTANT VERIFICATION ─────────────────────────────
print()
print("=" * 60)
print("SECTION 5: PHYSICAL CONSTANTS CROSS-CHECK")
print("=" * 60)
print()

HC_EV_CM = 1.23984193e-4
h_J  = 6.62607015e-34
c_m  = 2.99792458e8
e_J  = 1.602176634e-19
HC_computed = (h_J * c_m * 100) / e_J   # 100 cm/m conversion

print(f"  HC_EV_CM used:     {HC_EV_CM:.8e} eV·cm")
print(f"  HC_EV_CM computed: {HC_computed:.8e} eV·cm")
print(f"  Difference:        {abs(HC_EV_CM - HC_computed):.2e}")
assert abs(HC_EV_CM - HC_computed) < 1e-10, "HC_EV_CM mismatch"
print("  PASS: Constants are consistent.")
print()

# IVR conversion
C_CM_S = 2.99792458e10
tau_3ps = 3e-12
Gamma_ivr = 1 / (2 * math.pi * C_CM_S * tau_3ps)
print(f"  tau_IVR = 3 ps -> Gamma_IVR = 1/(2*pi*c*tau)")
print(f"    = 1 / (2*pi * {C_CM_S:.6e} * {tau_3ps:.1e})")
print(f"    = {Gamma_ivr:.4f} cm^-1")
print(f"  Expected: 1.770 cm^-1  |  Match: {abs(Gamma_ivr - 1.770) < 0.001}")
print()

# K-Fe chi verification
chi_kfe = 0.45 / (2 * HC_EV_CM * 1415)
print(f"  N2/K-Fe: chi = 0.45 / (2 * {HC_EV_CM:.8e} * 1415)")
print(f"         = 0.45 / {2 * HC_EV_CM * 1415:.8f}")
print(f"         = {chi_kfe:.6f}")
print(f"  Expected: 1.2825  |  Match: {abs(chi_kfe - 1.2825) < 1e-4}")
print()
print("ALL VERIFICATIONS COMPLETE.")
