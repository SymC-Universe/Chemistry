import numpy as np

print("--- EXACT ANALYTICAL P-VALUE CALCULATION ---\n")

# 1. Define the mathematical space
log_range_total = 1.0 - (-4.0)  # 5 orders of magnitude
window_width = np.log10(1.2) - np.log10(0.8) # ~0.176

# 2. Calculate single-event probability
p_single = window_width / log_range_total
print(f"Probability of 1 system landing in window by chance: {p_single*100:.2f}%")

# 3. Calculate exact p-value for N optimal systems
N_optimal_systems = 4 # (Replace with the number of systems you actually cite)
exact_p_value = p_single ** N_optimal_systems

print(f"Number of cross-domain optimal systems: {N_optimal_systems}")
print(f"Exact Analytical p-value: {exact_p_value:.6f}")

if exact_p_value < 0.05:
    print("\nCONCLUSION: STATISTICALLY SIGNIFICANT.")
    print("The null hypothesis is mathematically rejected without simulation.")