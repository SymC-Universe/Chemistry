import math

def test8_p_value(n_independent: int,
                  w_min: float = 0.8, w_max: float = 1.2,
                  log_min: float = -4.0, log_max: float = 1.0) -> dict:
    """Test 8: Computes the p-value for N independent systems falling in the window."""
    log_range = log_max - log_min
    window_frac = math.log10(w_max) - math.log10(w_min)

    p_single = window_frac / log_range
    log10_p = n_independent * math.log10(p_single)

    return {
        "p_single_pct": round(p_single * 100, 4),
        "log10_p": round(log10_p, 3),
        "p_exact": 10 ** log10_p,
        "significant": log10_p < math.log10(0.05)
    }

# Execute for our 3 strictly independent systems
n_systems = 3
results = test8_p_value(n_systems)

print(f"--- TEST 8: CROSS-DOMAIN CLUSTERING STATISTICAL AUDIT ---")
print(f"Independent Systems Count (N): {n_systems}")
print(f"1. Heterogeneous Catalysis (Fe(111) K-promoted)")
print(f"2. Electron Transfer (Ferrocene self-exchange, Weaver)")
print(f"3. PCET (Ruthenium complex high-pressure transition, Langford 2025)")
print(f"-------------------------------------------------------")
print(f"Probability of a single system falling in [0.8, 1.2] by chance: {results['p_single_pct']}%")
print(f"Combined p-value for N={n_systems} systems: {results['p_exact']:.2e}")
print(f"Log10(p): {results['log10_p']}")
print(f"Statistically Significant (p < 0.05)? {results['significant']}")